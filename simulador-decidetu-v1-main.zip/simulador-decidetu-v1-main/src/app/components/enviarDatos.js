export default function enviarDatosAlServidor(edad, anosCotizados, anosRestantes, sexo, rentaImponible, beneficioCI, beneficioSsp) {
    console.log(edad, anosCotizados, anosRestantes, sexo, rentaImponible, beneficioCI, beneficioSsp);
    const url = "https://tu-servidor.com/api/calculo-beneficios";
    const data = {
      edad,
      anosCotizados,
      anosRestantes,
      sexo,
      rentaImponible,
      beneficioCI,
      beneficioSsp,
    };
  
    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    };
    
    /*
    fetch(url, options)
      .then((response) => {
        if (response.ok) {
          // Mostrar mensaje de éxito al usuario
        } else {
          // Mostrar mensaje de error al usuario
        }
      })
      .catch((error) => {
        // Mostrar mensaje de error al usuario
      });
    */
  }
  