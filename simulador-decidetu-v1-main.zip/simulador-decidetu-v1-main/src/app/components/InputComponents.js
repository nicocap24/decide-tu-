import React from 'react';

const InputComponent = ({ label, value, onChange, type = 'text' }) => (
  <div class="mb-3 col text-center d-flex align-content-between flex-wrap">
    <h5>{label}</h5>
    <input class="form-control-plaintext text-center custom-input" aria-label={label} type={type} value={value} onChange={onChange} />
  </div>
);

export default InputComponent;