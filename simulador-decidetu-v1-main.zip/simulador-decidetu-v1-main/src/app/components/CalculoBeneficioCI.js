export function calculoBeneficioCI(cnu, saldoAcumCI){
    return (cnu === 0) ? 0 : Math.round(saldoAcumCI / (cnu * 12) );
}