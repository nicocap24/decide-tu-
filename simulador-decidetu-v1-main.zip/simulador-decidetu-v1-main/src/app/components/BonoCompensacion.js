export function calculaBonoCompensacionExpectativaVida(pafe, uf){
    const res1 = ((pafe * 1.134) - pafe) * 0.25;
    const res2 = 18 * uf;
    return Math.min(res1, res2);
}