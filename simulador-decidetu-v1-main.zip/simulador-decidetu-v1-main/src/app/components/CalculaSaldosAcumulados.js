const calculaSaldosAcumulados = (rentaImponible, tasaCIsobreSueldo, tasaCIsobreSueldoPromedio, anosRestantes, faltaparaJubilacion, ingresoPromedio, cotizacionSSp, rentabAnualFFPP) => {
    const numeros = Array.from({length: faltaparaJubilacion}, (_, i) => i + 1 );

    let cotizacion = 0;
    let acumuladoRestante = 0;
    let v1 = 0;
    let v2 = 0;
    let cotizacion2 = 0;
    let acumuladoCi = 0;
    let v3 = 0;
    let v4 = 0;
    let primer = 0;
    let anterior = 0;
    numeros.forEach(numero => {
        v1 = rentaImponible * tasaCIsobreSueldo * 12 * (anosRestantes/faltaparaJubilacion);
        v2 = ingresoPromedio * 12 * tasaCIsobreSueldoPromedio * (anosRestantes/faltaparaJubilacion);
        cotizacion = v1 + v2;
        acumuladoRestante = cotizacion * (1 + rentabAnualFFPP/2) + acumuladoRestante * (1 + rentabAnualFFPP);

        v3 = rentaImponible * cotizacionSSp * 0.7 * 12 * (anosRestantes/faltaparaJubilacion);
        v4 = ingresoPromedio * 12 * cotizacionSSp * (anosRestantes/faltaparaJubilacion) * 0.3;
        cotizacion2 = v3 + v4;
        if (numero === 1){
            primer = cotizacion2 * (1 + rentabAnualFFPP/2);
        }
        acumuladoCi = primer + anterior * (1 + rentabAnualFFPP);

        anterior = acumuladoCi;
    });
    console.log({acumuladoRestante,  acumuladoCi});
    return { acumuladoRestante, acumuladoCi };
};

export default calculaSaldosAcumulados;