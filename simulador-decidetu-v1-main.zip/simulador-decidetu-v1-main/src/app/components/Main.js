import React from 'react';
import question from '../assets/images/question.png';

const Main = ({ repartir }) => {
    return (
        <main>
            <div class="container-fluid bg-info bg-gradient stp-head-landing">
                <div class="container">
                    <div class="row row-cols-1 row-cols-md-2 g-4 pt-3">
                        <div class="col-md-8 d-flex align-items-center justify-content-center"> 
                            <div>
                                <h1>Seguro Social o Cotización Individual</h1>
                                <h2>¿Cuál me beneficia más?</h2>
                                <p>En base a tus características, calculamos el beneficio que te entrega cotizar un {repartir*100}% al seguro social versus cotizar el mismo porcentaje a tu cuenta individual.</p>
                            </div>
                        </div>
                        <div class="col-md-4"> 
                            <img src={question} class="img-fluid" alt="Pensión Fi" /> 
                        </div>
                    </div>
                </div>
            </div>
        </main>
    );
};

export default Main;