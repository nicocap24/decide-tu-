import React from 'react';

const Resultados = ({ beneficioCI, beneficioSsp, cotizacionSSp }) => (
  <div className="row p-4 resultado">
    <div class="col text-center">
      Beneficio Seguro Social Previsional*: <h1>{Number(beneficioSsp).toLocaleString('es-CL',  { style: 'currency', currency: 'CLP' })}</h1>
    </div>

    <div class="col text-center">
      Beneficio Cotización Individual: <h1>{Number(beneficioCI).toLocaleString('es-CL',  { style: 'currency', currency: 'CLP' })}</h1>
    </div>
    <small class="text-center p-4">
        *Si destinas un {cotizacionSSp*100}% de cotización al SEGURO SOCIAL, recibirás un beneficio mensual de {Number(beneficioSsp).toLocaleString('es-CL',  { style: 'currency', currency: 'CLP' })}. 
        En cambio, si ese {cotizacionSSp*100}% de cotización lo destinas a tu CUENTA INDIVIDUAL, recibirás un beneficio mensual de {Number(beneficioCI).toLocaleString('es-CL',  { style: 'currency', currency: 'CLP' })}
    </small>
  </div>
  
);

export default Resultados;