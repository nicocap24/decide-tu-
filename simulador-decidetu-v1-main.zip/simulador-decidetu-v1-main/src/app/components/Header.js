import React from 'react';
import logo from '../assets/images/logotipo.png';

const Header = () => {
    return (
        <header class="header-container p-4 shadow-lg sticky-top">
            <div class="container">
                <div class="d-flex flex-wrap align-items-center justify-content-between"> 
                    <a href="pensiofi.com" class="d-flex align-items-center mb-2 mb-lg-0 link-body-emphasis text-decoration-none me-auto"> 
                        <img src={logo} alt="Setop Oil" width="171" /> 
                    </a>
                </div>
            </div>
        </header>
    );
};

export default Header;