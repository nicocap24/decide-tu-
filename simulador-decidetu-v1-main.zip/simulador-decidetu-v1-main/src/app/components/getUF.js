import { useEffect } from 'react';

function ObtenerUF({setValorUF}) {
    useEffect(() => {
        fetch('https://mindicador.cl/api/uf')
            .then(response => response.json())
            .then(data => setValorUF(data.serie[0].valor))
            .catch(error => console.error(error));
    }, [setValorUF]);

    return null;    // no renderiza nada
}

export default ObtenerUF;