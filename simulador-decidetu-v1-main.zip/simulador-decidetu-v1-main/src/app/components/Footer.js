import React from 'react';

function Footer({ valorUF }) {
    return (
        <footer class="bg-dark text-light py-3 mt-auto">
            <div class="container text-center">
                <div class="row align-items-center">
                    <div class="col-md-6 text-md-end">  </div>
                    <div class="col-md-6 text-md-start">
                        <p class="text-light mb-0 small">Desarrollado por @PensionFI</p>
                    </div>
                </div>
            </div>
        </footer>
    );
}

export default Footer;