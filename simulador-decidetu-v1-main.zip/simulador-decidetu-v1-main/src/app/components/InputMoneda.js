import React from 'react';
import {NumericFormat} from 'react-number-format';

const InputMoneda = ({ label, value, onChange }) => (
  <div class="mb-3 col">
    <label>
      <h6>{label}</h6>
    </label>
    <NumericFormat 
        class="form-control text-center"
        aria-label={label}
        prefix={'$'} 
        decimalScale={0} 
        fixedDecimalScale={true} 
        allowNegative={false} 
        value={value} 
        onValueChange={values => onChange(values.value)}
        decimalSeparator=","
        thousandSeparator="." />
  </div>
);

export default InputMoneda;