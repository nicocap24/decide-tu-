const calculaBonoExpectativaVida = (edad, rentaImponible, tasaCIsobreSueldo, tasaCIsobreSueldoPromedio, anosCotizados, completoAntesEdadActual, anosRestantes, faltaparaJubilacion, ingresoPromedio, rentabAnualFFPP, cnu, sexo, edadJubilacionM, edadJubilacionF) => {
    const limite = (sexo === 'M') ? edadJubilacionM : edadJubilacionF;
    const numeros = Array.from({length: limite - 18 + 1}, (_, i) => i + 18);

    let cotizacion = 0;
    let acumulado = 0;
    let v1 = 0;
    let v2 = 0;
    let v3 = 0;
    numeros.forEach(numero => {
        if (edad > numero){
            v1 = rentaImponible * tasaCIsobreSueldo * 12 * (anosCotizados/completoAntesEdadActual);
            v2 = rentaImponible * 0.1 * 12 * (anosCotizados/completoAntesEdadActual);
            v3 = ingresoPromedio * 12 * tasaCIsobreSueldoPromedio * (anosCotizados/completoAntesEdadActual);
        } else {
            v1 = rentaImponible * tasaCIsobreSueldo * 12 * (anosRestantes/faltaparaJubilacion);
            v2 = rentaImponible * 0.1 * 12 * (anosRestantes/faltaparaJubilacion);
            v3 = ingresoPromedio * 12 * tasaCIsobreSueldoPromedio * (anosRestantes/faltaparaJubilacion);
        }
        cotizacion = v1 + v2 + v3;

        acumulado = cotizacion * (1 + rentabAnualFFPP/2) + acumulado * (1 + rentabAnualFFPP);
    });
    console.log('calculo bono expectativa de vida',cnu, cotizacion, acumulado, acumulado / (cnu * 12));
    return acumulado / (cnu * 12);
};

export default calculaBonoExpectativaVida;