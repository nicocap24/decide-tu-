import React, { useEffect, useState } from 'react';
import Header from './Header';
import '../assets/css/stp-class.css';
import ObtenerUF from './getUF';
import Footer from './Footer';
import { calculaBonoCompensacionExpectativaVida } from './BonoCompensacion';
import Resultados from './Resultados';
import InputComponent from './InputComponents';
import InputMoneda from './InputMoneda';
import calculaBonoExpectativaVida from './CalculaBonoExpectativaVida';
import calculaSaldosAcumulados from './CalculaSaldosAcumulados';
import Main from './Main';
import enviarDatosAlServidor from './enviarDatos';
import { calculoBeneficioCI } from './CalculoBeneficioCI';
import { calculoBeneficioSsp } from './CalculoBeneficioSsp';
// import SliderComponent from './SliderComponent';
import BotonCalcular from './BotonCalcular';

function App() {
    // parametros pantalla
    const [edad, setEdad] = useState('');
    const [anosCotizados, setAnosCotizados] = useState('');
    const [anosRestantes, setAnosRestantes] = useState('');
    const [sexo, setSexo] = useState('');
    const [rentaImponible, setRentaImponible] = useState('');

    // constantes
    const [repartir] = useState('0.06');    // 6% a repartir
    const [ingresoPromedio] = useState(1100000);
    const [edadJubilacionF] = useState(62);
    const [edadJubilacionM] = useState(65);
    const [cotizacionSSp, setCotizacionSSp] = useState(0.03);       // 3%
    const [rentabAnualFFPP] = useState(0.04);   // 4%

    // salidas de pantalla
    const [beneficioSsp, setBeneficioSsp] = useState(0);
    const [beneficioCI, setBeneficioCI] = useState(0);


    const [tasaCIsobreSueldo, setTasaCIsobreSueldo] = useState(0);
    const [tasaCIsobreSueldoPromedio, setTasaCIsobreSueldoPromedio] = useState(0);
    const [valorUF, setValorUF] = useState(null);
    const [cnu, setCNU] = useState(null);
    const [faltaparaJubilacion, setFaltaparaJubilacion] = useState(0);
    const [completoAntesEdadActual, setCompletoAntesEdadActual] = useState(0);
    //const [pafe, setPafe] = useState(0);
    //const [bonoExpectativaVida, setBonoExpectativaVida] = useState(0);

    const [saldoAcumCI, setSaldoAcumCI] = useState(0);
    const [saldoAcumRestante, setSaldoAcumRestante] = useState(0);

    // interaccion con variables de pantalla
    useEffect(()=> {
        setTasaCIsobreSueldo((repartir - cotizacionSSp)*0.7);
    },[cotizacionSSp, repartir]);

    useEffect(() => {
        setTasaCIsobreSueldoPromedio((repartir - cotizacionSSp)*0.3);
    },[cotizacionSSp, repartir]);
    
    useEffect(() => {
        console.log('useefect sexo');
        if (sexo === 'M') {
            setCNU(14.7);
        } else if (sexo === 'F') {
            setCNU(18.2);
        } else {
            setCNU(0);
        }
    }, [sexo]);

    useEffect(() => {
        console.log('useefect edad, edadJubilacionF, edadJubilacionM, sexo');
        if (sexo === 'M') {
            setFaltaparaJubilacion(edadJubilacionM - edad);
        } else if (sexo === 'F') {
            setFaltaparaJubilacion(edadJubilacionF - edad);
        } else {
            setFaltaparaJubilacion(0);
        }
    }, [edad, edadJubilacionF, edadJubilacionM, sexo]);

    useEffect(() => {
        setCompletoAntesEdadActual(edad - 18);
    }, [edad]);
    // --- 

    // calculo saldos acumulados
    useEffect(() => {
        console.log('calculo saldos acumulados',rentaImponible, tasaCIsobreSueldo, tasaCIsobreSueldoPromedio, anosRestantes, faltaparaJubilacion, ingresoPromedio, cotizacionSSp, rentabAnualFFPP);
        const { acumuladoRestante, acumuladoCi } = calculaSaldosAcumulados(rentaImponible, tasaCIsobreSueldo, tasaCIsobreSueldoPromedio, anosRestantes, faltaparaJubilacion, ingresoPromedio, cotizacionSSp, rentabAnualFFPP);
        console.log('resultado saldos acumulados=',{acumuladoRestante, acumuladoCi});
        setSaldoAcumRestante(acumuladoRestante);
        setSaldoAcumCI(acumuladoCi);
    }, [rentaImponible, tasaCIsobreSueldo, tasaCIsobreSueldoPromedio, anosRestantes, faltaparaJubilacion, ingresoPromedio, cotizacionSSp, rentabAnualFFPP])
        
    
    const calcularBeneficios = () => {
        if (!edad || !anosCotizados || !anosRestantes || !sexo || !rentaImponible) {
            alert('Por favor, completa todos los campos.');
            return;
        }

        if (valorUF) {
            // calculo pafe
            const pafe = calculaBonoExpectativaVida(edad, rentaImponible, tasaCIsobreSueldo, tasaCIsobreSueldoPromedio, anosCotizados, completoAntesEdadActual, anosRestantes, faltaparaJubilacion, ingresoPromedio, rentabAnualFFPP, cnu, sexo, edadJubilacionM, edadJubilacionF);
            console.log('valor recibido nuevoPafe=', pafe);

            // calculo bono compensacion expectativa de vida
            const bonoExpectativaVida = calculaBonoCompensacionExpectativaVida(pafe, valorUF);
            //setBonoExpectativaVida(bono);
            console.log('bono calculado', bonoExpectativaVida);

            console.log(`el valor de la UF es ${valorUF}`);
            console.log(`valor tasa cotizacion CI sobre sueldo ${tasaCIsobreSueldo}`);
            console.log(`valor tasa cotizacion CI sobre sueldo promedio ${tasaCIsobreSueldoPromedio}`);
            console.log(`años faltante para jubilar ${faltaparaJubilacion}`);
            console.log(`completoAntesEdadActual ${completoAntesEdadActual}`);
            console.log(`Saldo Acumulado en CI por cotizar el mismo % que en el SSP ${saldoAcumCI}`);
            console.log(`Saldo Acumulado por % restante del 6% destinado a CI ${saldoAcumRestante}`);

            console.log(`beneficio seguro social provesional ${beneficioSsp}`);
            console.log(`beneficio cotizacion individual ${beneficioCI}`);

            // calculo beneficio cotizacion individual
            let resultado = calculoBeneficioCI(cnu, saldoAcumCI);
            setBeneficioCI(resultado);
    
            // calculo beneficio seguro social previsional
            resultado = calculoBeneficioSsp(cotizacionSSp, sexo, tasaCIsobreSueldo, anosCotizados, anosRestantes, valorUF, saldoAcumRestante, cnu, bonoExpectativaVida);
            setBeneficioSsp(resultado);
    
            enviarDatosAlServidor(edad, anosCotizados, anosRestantes, sexo, rentaImponible, beneficioCI, beneficioSsp);

        }
    };

    return (
        <div className="d-flex flex-column min-vh-100">
            <Header />
            
            <Main repartir={repartir}/>

            <div className="container stp-form-content mt-3 p-4">
                <div class="card">
                    <div class="card-header stp-card-header-1">
                        <h4><i class="bi bi-calculator-fill"></i> Calcula tu beneficio </h4>
                    </div>

                    <div className="card-body p-4">
                        <div class="row row-cols-3 row-cols-md-3 g-4">
                            <InputComponent 
                                label="¿Cuál es tu edad actualmente?" 
                                value={edad} 
                                onChange={e => setEdad(e.target.value)} 
                                type="number" />
                            <InputComponent 
                                label="¿Cuántos años has cotizado hasta la actualidad?" 
                                value={anosCotizados} 
                                onChange={e => setAnosCotizados(e.target.value)} 
                                type="number" />
                            <InputComponent 
                                label="¿Cuántos años esperas cotizar desde ahora hasta el momento en que te jubiles?" 
                                value={anosRestantes} 
                                onChange={e => setAnosRestantes(e.target.value)} 
                                type="number" />
                        </div>

                        <div class="row row-cols-3 row-cols-md-3 g-4">
                            <div class="mb-3 col">
                                <label>
                                    <h6>¿Cuál es tu sexo?</h6>
                                </label>
                                <select class="form-select" value={sexo} onChange={e => setSexo(e.target.value)}>
                                    <option value="">Selecciona...</option>
                                    <option value="M">Masculino</option>
                                    <option value="F">Femenino</option>
                                </select>
                            </div>
                            <InputMoneda 
                                label="¿Cuál es tu renta imponible actual?" 
                                value={rentaImponible} 
                                onChange={value => setRentaImponible(value)} />
                            {/* <SliderComponent 
                                label="Tasa cotización Seguro Social Previsional"
                                value={cotizacionSSp}
                                onChange={e => setCotizacionSSp(e.target.value)} /> */}
                            <BotonCalcular onClick={calcularBeneficios} />
                        </div>
                    </div>
                </div>
            </div>

            <div class="container">
                <Resultados beneficioCI={beneficioCI} beneficioSsp={beneficioSsp} cotizacionSSp={cotizacionSSp} />
            </div>

            <ObtenerUF setValorUF={setValorUF} />
            <Footer valorUF={valorUF} />
        </div>

    );
}

export default App;