export function calculoBeneficioSsp(cotizacionSSp, sexo, tasaCIsobreSueldo, anosCotizados, anosRestantes, valorUF, saldoAcumRestante, cnu, bonoExpectativaVida){
    let resultado = 0;
    //console.log('calculo benefio seguro social=',cotizacionSSp, sexo, tasaCIsobreSueldo, anosCotizados, anosRestantes, valorUF, saldoAcumRestante, cnu, bonoExpectativaVida);
    if ( cotizacionSSp > 0 && sexo !== '') {
        let valorInterno = 0;
        console.log('anosCotizados , anosRestantes',anosCotizados, anosRestantes, ' y la suma es = ',(Number(anosCotizados) + Number(anosRestantes)));
        console.log('min 30', Math.min( 30, (Number(anosCotizados) + Number(anosRestantes)) ));
        if ( tasaCIsobreSueldo < 0.06) {
            valorInterno = Math.min( 30, (Number(anosCotizados) + Number(anosRestantes)) ) * ( 0.1 * valorUF) - ( saldoAcumRestante/( cnu * 12));
        }
        resultado += Math.round(Math.max(0, valorInterno));

        if ( sexo !== 'M'){
            resultado += bonoExpectativaVida;
        }
    }
    console.log('resultado calculo beneficio seguro social previsional=', Math.round(resultado));
    return Math.round(resultado);
}