import React from 'react';

function BotonCalcular({onClick}){
    return (
    <div class="mb-3 col text-center d-flex align-content-end flex-wrap">
        <button class="btn btn-success" onClick={onClick}>
            <i class="bi bi-arrow-clockwise"></i> Calcular Beneficios
        </button>
    </div>
    );
}

export default BotonCalcular;