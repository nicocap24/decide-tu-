require('dotenv').config(); // npm install dotenv
const port = process.env.REACT_APP_PUERTO_BACKEND;
const express = require('express'); // npm install express
const cors = require('cors'); // npm install cors
const axios = require('axios'); // npm install axios
const bodyParser = require('body-parser'); //npm install body-parser
const { v4: uuidv4 } = require('uuid'); //npm install uuid

const app = express();

const whitelist = [
	'https://simulador-spp-v2-staging.vercel.app',
	'https://decidetu.cl',
	'https://www.decidetu.cl',
]; // lista de sitios permitidos
const DECIDETU_URL = process.env.REACT_APP_API_G_SHEET;
const corsOptions = {
	origin: function (origin, callback) {
		// para solicitudes que se originan en el mismo sitio el "origin" es indefinido
		if (
			!origin ||
			origin.startsWith('http://localhost:') ||
			whitelist.indexOf(origin) !== -1
		) {
			callback(null, true);
		} else {
			callback('Not allowed by CORS'); //callback(new Error('Not allowed by CORS')) esto envìa mucho texto de error
		}
	},
	optionsSuccessStatus: 200,
};

app.use(cors(corsOptions));

//sin el body-parser node no puede leer el body
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get('/', (req, res) => {
	//console.log(req.body);
	//console.log(process.env);
	res.json('Bienvenido a mi Backend');
});

app.get('/getUf', (req, res) => {
	const options = {
		method: 'GET',
		url: 'https://mindicador.cl/api/uf',
	};

	axios
		.request(options)
		.then(response => {
			res.json(response.data);
		})
		.catch(error => {
			console.error(error);
		});
});

app.post('/sndCalculos', async (req, res) => {
	const { recaptchaToken } = req.body;
	// Verificar si req.body contiene datos
	if (!req.body || Object.keys(req.body).length === 0) {
		console.error('No se enviaron datos');
		res.status(400).send('No se enviaron datos');
		return;
	}

	// Verificar si reCaptcha existe
	if (recaptchaToken === null || recaptchaToken === undefined) {
		return res.status(400).send({ msg: 'ERROR:Fail reCaptcha Auth' });
	}

	//Verificar validez de reCaptcha
	try {
		const response = await axios.post(
			`https://www.google.com/recaptcha/api/siteverify?secret=${process.env.REACT_APP_DECIDETU_CAPTCHA_SECRETKEY}&response=${recaptchaToken}`
		);
		if (
			!response.data.success ||
			response.data.score < 0.5 ||
			response.data.action !== 'calDatosAreaFormDECIDETU'
		) {
			return res.status(400).send({ msg: 'ERROR_RECAPTCHA_AUTHENTICATION' });
		}
	} catch (error) {
		return res.status(500).send({ msg: 'ERROR_INTERNAL_CAPTCHA' });
	}

	//No es necesario guardar el token del captcha en la base de datos
	delete req.body.recaptchaToken;
	req.body.beneficioSsp = String(req.body.beneficioSsp);
	req.body.beneficioCI = String(req.body.beneficioCI);

	//Creacion de iD
	const ID = uuidv4();
	req.body.ID = ID;

	// CONEXION A GOOGLE SHEET
	const G_options = {
		method: 'POST',
		url: `${DECIDETU_URL}?endpoint=simulacion`,
		headers: {
			'Content-Type': 'application/json',
		},
		data: req.body,
	};

	axios
		.request(G_options)
		.then(response => {
			// console.log(response.data);
			return res.status(200).send({ id: ID });
		})
		.catch(error => {
			// console.log('error');
			return res.status(500).send({ msg: 'bad' }); // Enviar el error al frontend
		});

	// CONEXION A BASE DE DATOS
	// const options = {
	// 	method: 'POST',
	// 	url: process.env.REACT_APP_API_REGISTRAR_URL,
	// 	headers: {
	// 		'Content-Type': 'application/json',
	// 	},
	// 	data: req.body,
	// };

	// axios
	// 	.request(options)
	// 	.then(response => {
	// 		return res.json(response.data);
	// 	})
	// 	.catch(error => {
	// 		return res.status(500).send(error.toString()); // Enviar el error al frontend
	// 	});
});

app.post('/sndRating', async (req, res) => {
	const { recaptchaToken } = req.body;

	// Verificar si req.body contiene datos
	if (!req.body || Object.keys(req.body).length === 0) {
		console.error('No se enviaron datos');
		res.status(400).send('No se enviaron datos');
		return;
	}
	// Verificar si reCaptcha existe
	if (recaptchaToken === null || recaptchaToken === undefined) {
		return res.status(400).send({ msg: 'ERROR:Fail reCaptcha Auth' });
	}

	//Verificar validez de reCaptcha
	try {
		const response = await axios.post(
			`https://www.google.com/recaptcha/api/siteverify?secret=${process.env.REACT_APP_DECIDETU_CAPTCHA_SECRETKEY}&response=${recaptchaToken}`
		);
		if (
			!response.data.success ||
			response.data.score < 0.5 ||
			response.data.action !== 'EnvianosTusComentariosYLosRecibiremosConGusto'
		) {
			return res.status(400).send({ msg: 'ERROR_RECAPTCHA_AUTHENTICATION' });
		}
	} catch (error) {
		return res.status(500).send({ msg: 'ERROR_INTERNAL_CAPTCHA' });
	}
	delete req.body.recaptchaToken;

	// CONEXION A GOOGLE SHEET
	const G_options = {
		method: 'POST',
		url: `${DECIDETU_URL}?endpoint=evaluacion`,
		headers: {
			'Content-Type': 'application/json',
		},
		data: req.body,
	};

	axios
		.request(G_options)
		.then(response => {
			console.log(response.data);
			return res.status(200).send('ok');
		})
		.catch(error => {
			console.log(error.data);
			return res.status(500).send('Bad request'); // Enviar el error al frontend
		});

	//Conexion a base de datos
	// const options = {
	// 	method: 'POST',
	// 	url: process.env.REACT_APP_API_EVALUAR_URL,
	// 	headers: {
	// 		'Content-Type': 'application/json',
	// 	},
	// 	data: req.body, // En axios, el cuerpo de la solicitud se especifica con 'data', no con 'body',
	// };

	// axios
	// 	.request(options)
	// 	.then(response => {
	// 		res.json(response.data);
	// 	})
	// 	.catch(error => {
	// 		console.error(error, process.env.REACT_APP_API_EVALUAR_URL);
	// 		res.status(500).send(error.toString()); // Enviar el error al frontend
	// 	});
});

app.listen(port, () => {
	console.log(`Server runing at http://localhost:${port}`);
});
