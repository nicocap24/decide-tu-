import React from 'react';
import { NumericFormat } from 'react-number-format';

const InputMoneda = ({ label, value, onChange }) => (
	<div className="mb-3 stats mx">
		<div className="h-100 text-center d-flex flex-column justify-content-between  stats-inner nomrg">
			<label>
				<h5 className="stats-text">{label}</h5>
			</label>
			<NumericFormat
				className="form-control text-center"
				aria-label={label}
				prefix={'$'}
				decimalScale={0}
				fixedDecimalScale={true}
				allowNegative={false}
				// value={value}
				onValueChange={values => onChange(values.value)}
				decimalSeparator=","
				thousandSeparator="."
			/>
		</div>
	</div>
);

export default InputMoneda;
