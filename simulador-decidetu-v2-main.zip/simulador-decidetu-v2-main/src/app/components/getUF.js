import { useEffect } from 'react';

function ObtenerUF({setValorUF}) {
    useEffect(() => {
        const apiUrl = process.env.REACT_APP_API_URL || window.location.origin;
        fetch(`${apiUrl}/getUf`)
            .then(response => response.json())
            .then(data => setValorUF(data.serie[0].valor))
            .catch(error => console.error(error));
    }, [setValorUF]);

    return null;    // no renderiza nada
}

export default ObtenerUF;