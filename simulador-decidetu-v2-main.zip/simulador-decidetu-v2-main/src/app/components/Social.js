import React from 'react';

import { FaXTwitter } from 'react-icons/fa6';
import { IoLogoWhatsapp } from 'react-icons/io';
import { MdEmail } from 'react-icons/md';
import {
	WhatsappShareButton,
	EmailShareButton,
	TwitterShareButton,
} from 'react-share';

const Social = ({ bnsp, bci }) => {
	const URL_SITE = window.location.href;
	const DATA_SHARE = `Yo ya vi cómo me afecta la reforma previsional 😱
Mi beneficio sería de: ${Number(bnsp).toLocaleString('es-CL', {
		style: 'currency',
		currency: 'CLP',
	})} con Seguro Social y de: ${Number(bci).toLocaleString('es-CL', {
		style: 'currency',
		currency: 'CLP',
	})} con Capitalización Individual.	
Descubre tus resultados acá:
`;

	return (
		<div className="d-flex social">
			<div className="resultado_header">
				<div className="resultado_imagen-container">
					<img
						loading="lazy"
						src="https://cdn.builder.io/api/v1/image/assets/TEMP/fd6a1249d7f8e63cc6b4a4bbbbaff96dde91218556fe84b6433f43105a4a4b2d?apiKey=fa97ba7e80824a5c857b3c5ffc449f99&"
						className=""
						alt="Decide tu"
					/>
				</div>
				<div>
					<h5 className="text-center m-0 resultado_header-title">
						¡DECIDE TÚ!
					</h5>
					<h6 className="text-center m-0 resultado_header-subtitle">
						Comparte tus resultados acá:
					</h6>
				</div>
			</div>
			<div className="social-icon-container">
				<WhatsappShareButton title={DATA_SHARE} separator=" " url={URL_SITE}>
					<div className="social-icon">
						<IoLogoWhatsapp />
					</div>
				</WhatsappShareButton>
				<TwitterShareButton
					url={URL_SITE}
					title={DATA_SHARE}
					hashtag="#als #dka #sldk"
				>
					<div className="social-icon">
						<FaXTwitter />
					</div>
				</TwitterShareButton>
				<EmailShareButton
					subject="Decide Tú: Reforma de Pensiones"
					body={DATA_SHARE}
					separator=" "
					url={URL_SITE}
				>
					<div className="social-icon">
						<MdEmail />
					</div>
				</EmailShareButton>
			</div>
		</div>
	);
};

export default Social;
