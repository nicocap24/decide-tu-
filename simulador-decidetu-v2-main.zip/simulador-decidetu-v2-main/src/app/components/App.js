import React, { useEffect, useState } from 'react';
import '../assets/css/App.css';
import ObtenerUF from './getUF';
import Footer from './Footer';
import { calculaBonoCompensacionExpectativaVida } from './BonoCompensacion';
import Resultados from './Resultados';
import InputComponent from './InputComponents';
import InputMoneda from './InputMoneda';
import calculaBonoExpectativaVida from './CalculaBonoExpectativaVida';
import enviarDatosAlServidor from './enviarDatos';
import { calculoBeneficioCI } from './CalculoBeneficioCI';
import { calculoBeneficioSsp } from './CalculoBeneficioSsp';
import BotonCalcular from './BotonCalcular';
import Decidetu from './Decidetu';
import relojImg from '../assets/images/reloj.png';
import pesoImg from '../assets/images/peso.png';
import peopleImg from '../assets/images/people.png';
import gFlechaImg from '../assets/images/grafico_flecha.png';
import gBarraImg from '../assets/images/grafico_barras.png';
import Social from './Social';
import CustomModal from './CustomModal';
import RatingComponent from './RatingComponent';
import TerminosComponent from './Terminos';
import Politicas from './Politicas';
import { Helmet } from 'react-helmet';
import ModalBeneficioSsp from './ModalBeneficioSsp';
import ModalBeneficioCi from './ModalBeneficioCi';
import Menu from './Menu';
import EdadModal from './EdadModal';
import useRecaptchaV3 from '../hooks/useRecaptchaV3';

function App() {
	// parametros pantalla
	const [edad, setEdad] = useState('');
	const [anosCotizados, setAnosCotizados] = useState(0);
	const [anosRestantes, setAnosRestantes] = useState(0);
	const [sexo, setSexo] = useState('');
	const [rentaImponible, setRentaImponible] = useState(0);
	const [isOpen, setIsOpen] = useState(false);
	const [terminos, setterminos] = useState(false);
	const [politica, setPolitica] = useState(false);
	const [infoBeneficioSsp, setInfoBeneficioSsp] = useState(false);
	const [infoBeneficioCi, setInfoBeneficioCi] = useState(false);
	const [isEdadModal, setIsEdadModal] = useState(false);
	const [capIndividual, setCapIndividual] = useState(false);
	// constantes
	const [repartir] = useState('0.06'); // 6% a repartir
	const [ingresoPromedio] = useState(1100000);
	const [edadJubilacionF] = useState(62);
	const [edadJubilacionM] = useState(65);
	const [cotizacionSSp /*, setCotizacionSSp*/] = useState(0.03); // 3%
	const [rentabAnualFFPP] = useState(0.04); // 4%
	const [topeImponible] = useState(84.3);

	// salidas de pantalla
	const [beneficioSsp, setBeneficioSsp] = useState(0);
	const [beneficioCI, setBeneficioCI] = useState(0);
	const [calcDisabled, setCalcDisabled] = useState(false);

	const [tasaCIsobreSueldo, setTasaCIsobreSueldo] = useState(0);
	const [tasaCIsobreSueldoPromedio, setTasaCIsobreSueldoPromedio] = useState(0);
	const [valorUF, setValorUF] = useState(null);
	const [cnu, setCNU] = useState(null);
	const [faltaparaJubilacion, setFaltaparaJubilacion] = useState(0);
	const [completoAntesEdadActual, setCompletoAntesEdadActual] = useState(0);

	const URL_SITE = window.location.href;

	const executeRecaptcha = useRecaptchaV3({
		SITE_KEY: process.env.REACT_APP_DECIDETU_CAPTCHA_SITEKEY,
	});
	//variable que almacena key de la tabla simulaciones y que luego se usa para guardar la evaluacion
	const [keyTabla, setKeyTabla] = useState('');

	// interaccion con variables de pantalla
	useEffect(() => {
		setTasaCIsobreSueldo((repartir - cotizacionSSp) * 0.7);
	}, [cotizacionSSp, repartir]);

	useEffect(() => {
		setTasaCIsobreSueldoPromedio((repartir - cotizacionSSp) * 0.3);
	}, [cotizacionSSp, repartir]);

	useEffect(() => {
		if (sexo === 'M') {
			setCNU(14.7);
		} else if (sexo === 'F') {
			setCNU(18.2);
		} else {
			setCNU(0);
		}
	}, [sexo]);

	useEffect(() => {
		if (sexo === 'M') {
			setFaltaparaJubilacion(edadJubilacionM - edad);
		} else if (sexo === 'F') {
			setFaltaparaJubilacion(edadJubilacionF - edad);
		} else {
			setFaltaparaJubilacion(0);
		}
	}, [edad, edadJubilacionF, edadJubilacionM, sexo]);

	useEffect(() => {
		setCompletoAntesEdadActual(edad - 18);
	}, [edad]);

	useEffect(() => {
		setCalcDisabled(false);
	}, [edad, sexo, rentaImponible, anosCotizados, anosRestantes]);

	const calcularBeneficios = async () => {
		if (!edad) {
			alert('Por favor, completa todos los campos.');
			return;
		}

		try {
			if (valorUF) {
				// calculo pafe
				setCapIndividual(false);
				const { pafe, acumuladoRestante, acumuladoCi } = calculaBonoExpectativaVida(
					edad,
					rentaImponible,
					tasaCIsobreSueldo,
					tasaCIsobreSueldoPromedio,
					anosCotizados,
					completoAntesEdadActual,
					anosRestantes,
					faltaparaJubilacion,
					ingresoPromedio,
					rentabAnualFFPP,
					cnu,
					sexo,
					edadJubilacionM,
					edadJubilacionF,
					valorUF,
					topeImponible,
					cotizacionSSp
				);

				// calculo bono compensacion expectativa de vida
				const bonoExpectativaVida = calculaBonoCompensacionExpectativaVida(
					pafe,
					valorUF
				);

				// calculo beneficio cotizacion individual
				const ben_ci = calculoBeneficioCI(cnu, acumuladoCi);
				setBeneficioCI(ben_ci);

				// calculo beneficio seguro social previsional
				const ben_ssp = calculoBeneficioSsp(
					cotizacionSSp,
					sexo,
					tasaCIsobreSueldo,
					anosCotizados,
					anosRestantes,
					valorUF,
					acumuladoRestante,
					cnu,
					bonoExpectativaVida,
					edad
				);
				setBeneficioSsp(ben_ssp);
				const recaptchaToken = await executeRecaptcha(
					'calDatosAreaFormDECIDETU'
				);
				await enviarDatosAlServidor(
					edad,
					anosCotizados,
					anosRestantes,
					sexo,
					rentaImponible,
					ben_ci,
					ben_ssp,
					recaptchaToken,
					{ setKeyTabla }
				);
				setCalcDisabled(true);
			}
		} catch (error) {
			console.error(error);
		}
	};
	return (
		<div className="custom-container">
			<Helmet>
				<title>Decide Tú</title>
				<meta
					name="description"
					content="Esta calculadora previsional te ayudará a saber qué te conviene: Pruébala y ¡decide tú!."
				/>
				<meta property="og:url" content={URL_SITE} />
				<meta property="og:type" content="website" />
				<meta property="og:title" content="Decide Tú" />
				<meta
					property="og:description"
					content="Esta calculadora previsional te ayudará a saber qué te conviene: Pruébala y ¡decide tú!"
				/>
				<link rel="canonical" href={URL_SITE} />
				<base href={URL_SITE} />
				<meta name="twitter:card" content="summary_large_image" />
				<meta name="twitter:site" content="@nytimesbits" />
				<meta property="twitter:domain" content="decidetu.cl" />
				<meta property="twitter:url" content={URL_SITE} />
				<meta name="twitter:title" content="Decide Tú" />
				<meta
					name="twitter:description"
					content="Esta calculadora previsional te ayudará a saber qué te conviene: Pruébala y ¡decide tú!"
				/>
			</Helmet>
			<Menu />
			<Decidetu />

			<div className="stp-form-content mt-3 px-2">
				<div className="">
					<div className="d-flex flex-column justify-content-center card-body p-4">
						<div className="stats-container gap-2 m-auto">
							<InputComponent
								label="¿Cuántos años tienes?"
								image={relojImg}
								onChange={e => {
									//console.log(e.target.valueAsNumber);
									setEdad(Number(e.target.valueAsNumber));
								}}
								type="number"
							/>
							<InputComponent
								label="¿Cuál es tu género?"
								value={sexo}
								image={peopleImg}
								onChange={e => {
									setSexo(e.target.value);
								}}
								type="select"
							/>
							<InputMoneda
								label="¿Cuál es tu renta imponible actual?"
								image={pesoImg}
								onChange={e => {
									setRentaImponible(e);
								}}
								type="number"
							/>
						</div>
						<div className="stats-container stats2 gap-2 m-auto">
							<InputComponent
								label="¿Cuántos años has cotizado hasta la actualidad?"
								image={gBarraImg}
								onChange={e => setAnosCotizados(e.target.valueAsNumber)}
								type="number"
							/>
							<InputComponent
								label="Cuántos años esperas cotizar desde hoy hasta jubilar?"
								image={gFlechaImg}
								onChange={e => setAnosRestantes(e.target.valueAsNumber)}
								type="number"
								setIsEdadModal={setIsEdadModal}
								showEdad={true}
							/>
						</div>
					</div>
					<div className="col-12 col-md-3 m-auto">
						<BotonCalcular
							onClick={calcularBeneficios}
							calcDisabled={calcDisabled}
						/>
					</div>
				</div>
			</div>

			<Resultados
				beneficioCI={beneficioCI}
				beneficioSsp={beneficioSsp}
				cotizacionSSp={cotizacionSSp}
				setInfoBeneficioCi={setInfoBeneficioCi}
				setInfoBeneficioSsp={setInfoBeneficioSsp}
				capIndividual={capIndividual}
				setCapIndividual={setCapIndividual}
			/>
			<Social bnsp={beneficioSsp} bci={beneficioCI} />
			<RatingComponent keyTabla={keyTabla} />
			<p className="text-center disclaimer">
				¿Quedaste con alguna duda?
				<br />
				<a href="https://calendly.com/nico-pensionfi/30min" target="_blank">
					Agenda
				</a>{' '}
				una sesión virtual de 15 minutos con nosotros y veamosla.
			</p>
			<ObtenerUF setValorUF={setValorUF} />
			{isEdadModal && (
				<EdadModal isEdadModal={isEdadModal} setIsEdadModal={setIsEdadModal} />
			)}
			{infoBeneficioSsp && (
				<ModalBeneficioSsp
					infoBeneficioSsp={infoBeneficioSsp}
					setInfoBeneficioSsp={setInfoBeneficioSsp}
				/>
			)}
			{infoBeneficioCi && (
				<ModalBeneficioCi
					infoBeneficioCi={infoBeneficioCi}
					setInfoBeneficioCi={setInfoBeneficioCi}
				/>
			)}

			{isOpen && <CustomModal open={isOpen} setopen={setIsOpen} />}
			<div className="TerminosComponent">
				{terminos && (
					<TerminosComponent terminos={terminos} setTerminos={setterminos} />
				)}
			</div>
			<div className="TerminosComponent">
				{politica && (
					<Politicas terminos={politica} setTerminos={setPolitica} />
				)}
			</div>
			<Footer
				valorUF={valorUF}
				setTerminos={setterminos}
				setPolitica={setPolitica}
				setopen={setIsOpen}
			/>
		</div>
	);
}

export default App;
