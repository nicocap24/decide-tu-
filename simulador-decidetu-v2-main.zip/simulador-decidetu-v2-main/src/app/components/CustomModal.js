import React from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

const CustomModal = ({ open, setopen }) => {
	const handleClose = () => setopen(false);
	return (
		<div className="modal_container">
			<Modal show={open} onHide={handleClose} animation={false}>
				<Modal.Header closeButton>
					<Modal.Title></Modal.Title>
				</Modal.Header>
				<Modal.Body>
					<h3 className="text-center">
						<strong>Supuestos detrás del Simulador</strong>
					</h3>
					<ul>
						<li>
							Este simulador no entrega como resultado una estimación de la
							pensión total del usuario. Este simulador sólo entrega cómo
							resultado los beneficios que obtendría el usuario con el 6% de
							cotización extra que se estipula la reforma.
						</li>
						<li>
							Se asume una cotización extra del 6%, la cual se distribuye entre
							3% Seguro Social y 3% Capitalización Individual.
						</li>
						<li>
							Se utiliza un tope imponible para la remuneración mensual de 84,3
							UF.
						</li>
						<li>
							No se incluye el 10% de cotización actual, sólo el 6% extra que
							está en discusión en la reforma.
						</li>
						<li>No incluye PGU ni ningún tipo de pensión estatal.</li>
						<li>
							Se asume una edad de jubilación de 62 años para la mujer,
							correspondiente a la edad promedio de jubilación reportada por las
							actuales jubiladas, según datos de la Superintendencia de
							Pensiones. Se elige este dato a fin de reflejar el actual
							escenario real presentado por las jubiladas, y considerar la
							entrega del bono por compensación de expectativas de vida.
						</li>
						<li>
							Se asume una edad de jubilación de 65 años para los hombres,
							puesto que esta última corresponde a la edad promedio de
							jubilación reportada por los actuales jubilados, mismo parámetro
							escogido en el caso de las mujeres.
						</li>
						<li>
							Se asume una edad de inicio de cotización de mínimo 18 años, por
							lo tanto, un hombre puede cotizar hasta 47 años, y la mujer, hasta
							42 años.
						</li>
						<li>
							Se considera solidaridad intrageneracional, con una distribución
							70% - 30% (establecido en el proyecto de ley).
						</li>
						<li>
							Se asume una rentabilidad de los fondos de pensiones del 4%,
							correspondiente a una aproximación de la rentabilidad histórica de
							los fondos de pensiones.
						</li>
						<li>
							Se asume un CNU fijo para hombres y otro para mujeres, ambos sin
							cónyuge, sin hijos. La razón de asumir un CNU fijo es para efectos
							de simplificar el cálculo, y debido a que se desconoce las tablas
							de mortalidad del futuro, cuya estimación además destaca por su
							alta complejidad.
						</li>
						<li>
							Se asume una fecha de jubilación al 31/06/2024 para el cálculo de
							los CNU antes mencionado, lo cual implica que la reforma entre en
							régimen previo a esta fecha. Asimismo, cabe destacar que modificar
							el mes en que se considera la jubilación del afiliado para el
							cálculo del CNU, no altera en gran medida el parámetro como tal.
						</li>
						<li>
							Para el cálculo de los CNU antes mencionados, se consideró una
							tasa del 3,2% correspondiente a la utilizada para la renta
							vitalicia, a fin de calcular una pensión no fluctuante para el
							afiliado
						</li>
						<li>
							No se incluye el complemento por cuidado de terceros. Esto debido
							a que son pocos afiliados que se beneficiarían de esta garantía, y
							además permite mantener la simplicidad del cuestionario.
						</li>
						<li>
							El beneficio social está calculado al valor UF actualizado
							automáticamente a diario.
						</li>
						<li>
							Se asume un ingreso promedio de los cotizantes del mes de
							$1.100.000, el cual corresponde a una aproximación del ingreso
							imponible promedio de los cotizantes durante el año 2023.
						</li>
						<li>
							No hay crecimiento salarial en la historia laboral de la persona.
							Se estableció este supuesto para mantener simplicidad en el
							cuestionario.
						</li>
						<li>
							Según lo determinado en el proyecto de ley, durante el periodo de
							régimen aquellas personas con una edad menor a 50 años que no
							coticen en el seguro social previsional antes cumplir los 50 años,
							no tendrán acceso al beneficio de las garantías ofrecidas. Dado lo
							anterior, y con la finalidad de facilitar la parametrización de
							esa cláusula, para efecto de los cálculos se asume que la reforma
							se encuentra en régimen, vigente desde comienzos del presente año.
						</li>
						<li>
							Es importante mencionar que, debido al desconocimiento de la
							historia laboral de la persona que utiliza la calculadora, existe
							un margen de error en aquellos usuarios que estén cerca de la edad
							límite.
						</li>
					</ul>
				</Modal.Body>
				<Modal.Footer>
					<Button
						variant="Primary"
						className="btn btn-outline-success"
						onClick={handleClose}
					>
						Cerrar
					</Button>
				</Modal.Footer>
			</Modal>
		</div>
	);
};

export default CustomModal;
