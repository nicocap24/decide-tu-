export default async function enviarDatosAlServidor(
	edad,
	anosCotizados,
	anosRestantes,
	sexo,
	rentaImponible,
	beneficioCI,
	beneficioSsp,
	recaptchaToken,
	{ setKeyTabla }
) {
	// Obtener la fecha y hora actuales en milisegundos desde el epoch
	const now = Date.now();

	// Crear un objeto Date a partir del timestamp actual
	const date = new Date(now);

	// Especificar la región y opciones de formato para Chile
	const options = {
		year: 'numeric',
		month: '2-digit',
		day: '2-digit',
		hour: '2-digit',
		minute: '2-digit',
		second: '2-digit',
		timeZone: 'America/Santiago', // Zona horaria específica de Chile
		hour12: false, // Utiliza formato de 24 horas
	};

	// Crear el formateador de fecha y hora para la región especificada
	const dateTimeFormat = new Intl.DateTimeFormat('es-CL', options);

	// Formatear la fecha
	const formattedDate = dateTimeFormat.format(date);
	try {
		//console.log(edad, anosCotizados, anosRestantes, sexo, rentaImponible, beneficioCI, beneficioSsp);
		const data = {
			edad,
			anosCotizados,
			anosRestantes,
			sexo,
			rentaImponible,
			beneficioCI,
			beneficioSsp,
			recaptchaToken,
			fechaPeticion: formattedDate, // Agregar la fecha actual
		};

		const options = {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify(data),
		};

		const apiUrl = process.env.REACT_APP_API_URL || window.location.origin;
		//console.log(`${apiUrl}/sndCalculos`);
		await fetch(`${apiUrl}/sndCalculos`, options)
			.then(async response => {
				const data = await response.json(); // obtener la respuesta del servidor
				//console.log(response);
				if (response.ok) {
					return data;
				} else {
					console.log(data);
					throw new Error(data);
				}
			})
			.then(data => {
				//devolver el id al llamador
				setKeyTabla(data.id);
				return data.id;
			})
			.catch(error => {
				// Mostrar mensaje de error al usuario
				console.error(error);
			});
	} catch (error) {
		console.error(error);
	}
}
