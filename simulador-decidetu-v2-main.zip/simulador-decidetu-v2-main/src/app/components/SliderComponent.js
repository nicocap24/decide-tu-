import React from 'react';

const SliderComponent = ({ label, value, onChange }) => {
  <label>
    {label}
    <input type="range" min="0" max="6" value={value} onChange={onChange} />
  </label>
};

export default SliderComponent;