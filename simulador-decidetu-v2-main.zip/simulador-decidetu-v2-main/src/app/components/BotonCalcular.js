import React from 'react';

function CalculateBenefitsButton({ onClick, calcDisabled }) {
	return (
		<>
			<button
				type="button"
				className="w-100 btn text-center py-2 text-white rounded blue-bg"
				onClick={onClick}
				disabled={calcDisabled}
			>
				Quiero comparar beneficios
			</button>
		</>
	);
}

export default function BotonCalcular({ onClick, calcDisabled }) {
	return (
		<main className="w-100 text-center py-2 mb-4 text-white rounded blue-bg">
			<CalculateBenefitsButton onClick={onClick} calcDisabled={calcDisabled} />
		</main>
	);
}
