import React from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

const EdadModal = ({ isEdadModal, setIsEdadModal }) => {
	const handleClose = () => setIsEdadModal(false);
	return (
		<div className="modal_container">
			<Modal show={isEdadModal} onHide={handleClose} animation={false}>
				<Modal.Header closeButton>
					<Modal.Title></Modal.Title>
				</Modal.Header>
				<Modal.Body>
					<h3 className="text-center">
						<strong></strong>
					</h3>
					<ul>
						<li>
							Se asume una edad de jubilación de 62 años para la mujer,
							correspondiente a la edad promedio de jubilación reportada por las
							actuales jubiladas, según datos de la Superintendencia de
							Pensiones. Se elige este dato a fin de reflejar el actual
							escenario real presentado por las jubiladas, y considerar la
							entrega del bono por compensación de expectativas de vida.
						</li>
						<li>
							Se asume una edad de jubilación de 65 años para los hombres,
							puesto que esta última corresponde a la edad promedio de
							jubilación reportada por los actuales jubilados.
						</li>
					</ul>
				</Modal.Body>
				<Modal.Footer>
					<Button
						variant="Primary"
						className="btn btn-outline-success"
						onClick={handleClose}
					>
						Cerrar
					</Button>
				</Modal.Footer>
			</Modal>
		</div>
	);
};

export default EdadModal;
