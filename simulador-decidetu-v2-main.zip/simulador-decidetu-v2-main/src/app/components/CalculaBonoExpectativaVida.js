const crecimiento = (exponente) => {
	const factor = 0.015
	return Math.pow(1 + factor, exponente)
}

const salarioMasCrecimiento = (rentaImponible, exponente) => {
	const resultado = rentaImponible * 12 * crecimiento(exponente)
	return Math.round(resultado)
}

const calculaBonoExpectativaVida = (
	edad,
	rentaImponible,
	tasaCIsobreSueldo,
	tasaCIsobreSueldoPromedio,
	anosCotizados,
	completoAntesEdadActual,
	anosRestantes,
	faltaparaJubilacion,
	ingresoPromedio,
	rentabAnualFFPP,
	cnu,
	sexo,
	edadJubilacionM,
	edadJubilacionF,
	valorUF,
	topeImponible,
	cotizacionSSp
) => {
	const limite = sexo === 'M' ? edadJubilacionM - 1 : edadJubilacionF - 1;
	const numeros = Array.from({ length: limite - 18 + 1 }, (_, i) => i + 18);

	let cotizacion = 0;
	let acumulado = 0;
	let v1 = 0;
	let v2 = 0;
	let v3 = 0;

	let renta = 0;
	let factor = 0;

	let aux = edad - 18 + 1;		// 18 porque desde ahi comienza a iterar numeros
	let anio = 1;

	let salario = 0;

	// lo siguiente es usado para calculo saldos acumulados
	let acumuladoRestante = 0
    let cotizacionAnual = 0;
    let acumuladoCi = 0;
    
	numeros.forEach(numero => {
		if (edad > numero) {
			aux--;
			renta = (rentaImponible/crecimiento(aux)) <= topeImponible * valorUF ? rentaImponible/crecimiento(aux) : topeImponible * valorUF;	

			factor = anosCotizados <= completoAntesEdadActual ? anosCotizados / completoAntesEdadActual : 1;

			v1 = renta * 0.1 * 12 * factor;
			v2 = 0;
			v3 = 0;
		} else {
			salario = (salarioMasCrecimiento(rentaImponible, anio - 1)/12) <= topeImponible * valorUF ? salarioMasCrecimiento(rentaImponible, anio - 1)/12 : topeImponible * valorUF;

			factor = anosRestantes <= faltaparaJubilacion ? anosRestantes/faltaparaJubilacion : 1;
			v1 = salario * 0.1 * 12 * factor;

			v2 = salario * tasaCIsobreSueldo * 12 * factor;
			v3 = ingresoPromedio * tasaCIsobreSueldoPromedio * 12 * factor;

			// calculos saldos acumulados
			acumuladoRestante = (v2 + v3) * (1 + rentabAnualFFPP/2) + acumuladoRestante * (1 + rentabAnualFFPP);
			//console.log(v2+v3, acumuladoRestante)

			cotizacionAnual = salario * cotizacionSSp * 12 * factor;
			//console.log(cotizacionAnual, anio)

			acumuladoCi = (anio === 1) ? cotizacionAnual * (1 + rentabAnualFFPP/2) : 
										 cotizacionAnual * (1 + rentabAnualFFPP/2)  + acumuladoCi * (1 + rentabAnualFFPP);
		
			//console.log(anio, cotizacionAnual, acumuladoCi)
			anio++
		}
		cotizacion = v1 + v2 + v3;

		acumulado = cotizacion * (1 + rentabAnualFFPP / 2) + acumulado * (1 + rentabAnualFFPP);
	});
	const pafe = acumulado / (cnu * 12)
	return { pafe, acumuladoRestante, acumuladoCi };
};

export default calculaBonoExpectativaVida;
