import React from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

const ModalBeneficioCi = ({ infoBeneficioCi, setInfoBeneficioCi }) => {
	const handleClose = () => setInfoBeneficioCi(false);
	return (
		<div className="modal_container">
			<Modal show={infoBeneficioCi} onHide={handleClose} animation={false}>
				<Modal.Header closeButton>
					<Modal.Title></Modal.Title>
				</Modal.Header>
				<Modal.Body>
					<h3 className="text-center">
						<strong>
							¿Qué significa que 3% de cotización se destine a la cuenta
							individual?
						</strong>
						<p>
							El proyecto de ley propone que 3% (del 6%) de cotización adicional
							se destine a la cuenta de capitalización individual de los
							trabajadores. De este 3%, el 2,1% iría directamente a la cuenta de
							los afiliados y un 0,9% se repartiría de acuerdo al ingreso
							promedio de los cotizantes del mes
						</p>
					</h3>
					<p></p>
				</Modal.Body>
				<Modal.Footer>
					<Button
						variant="Primary"
						className="btn btn-outline-success"
						onClick={handleClose}
					>
						Cerrar
					</Button>
				</Modal.Footer>
			</Modal>
		</div>
	);
};

export default ModalBeneficioCi;
