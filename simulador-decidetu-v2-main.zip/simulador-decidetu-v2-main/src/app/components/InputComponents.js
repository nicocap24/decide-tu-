import React from 'react';
import { Form } from 'react-bootstrap';
import '../assets/css/CustomInput.css';

const renderInput = (type, onChange, value, label) => {
	switch (type) {
		case 'select':
			return (
				<Form.Select className="select" onChange={onChange}>
					<option value="">-Elegir-</option>
					<option value="M">Masculino</option>
					<option value="F">Femenino</option>
				</Form.Select>
			);
		case 'number':
			return (
				<Form.Control
					size="sm"
					type="number"
					onChange={onChange}
					className="custom-input"
					value={value}
					aria-label={label}
					min={0} // Solo para tipo "number"
				/>
			);
		case 'text':
		default:
			return (
				<Form.Control
					size="sm"
					type={type}
					onChange={onChange}
					className="custom-input"
					value={value}
					aria-label={label}
				/>
			);
	}
};

const InputComponent = ({
	label,
	value,
	image,
	onChange,
	setIsEdadModal,
	type = 'text',
	showEdad,
}) => (
	<div className="stats mb-4 position-relative">
		<div className="mr-4">
			<img src={image} alt={image} />
		</div>
		<div className="h-100 col  text-center d-flex flex-column justify-content-between  stats-inner">
			<h5 className="stats-text">
				{label}{' '}
				{showEdad && (
					<span onClick={() => setIsEdadModal(true)}>
						<strong className="text-white  px-2 info-symbol text-center bg-info">
							!
						</strong>
					</span>
				)}
			</h5>
			{renderInput(type, onChange, value, label)}
		</div>
	</div>
);

export default InputComponent;
