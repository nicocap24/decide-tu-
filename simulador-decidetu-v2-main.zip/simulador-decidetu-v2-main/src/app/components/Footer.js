import React from 'react';
import { useState } from 'react';

function Footer({ valorUF, setTerminos, setopen, setPolitica }) {
	const [first, setfirst] = useState(false);
	// const myf = () => {
	// 	setfirst(!first);
	// 	console.log(first);
	// };
	return (
		<>
			<h6 className="h4">
				<strong>Disclaimer</strong>
			</h6>
			<p className="disclaimer">
				Los resultados de este simulador deben considerarse cómo una orientación
				de carácter informacional y bajo ninguna circunstancia debe considerarse
				como asesoría previsional.
			</p>
			<p className="disclaimer">
				Página desarrollada con ❤️ por:{' '}
				<a href="https://www.pensionfi.com/" rel="noreferrer" target="_blank">
					Pension Fi.
				</a>
				<br /> Pension Fi es una empresa dedicada a diseñar, desarrollar y
				comunicar herramientas y productos previsionales.
			</p>
			<a className="linkpopup" onClick={() => setopen(true)}>
				<u>
					<br />
					Supuestos
				</u>
			</a>
			<a className="linkpopup" onClick={() => setTerminos(true)}>
				<u>
					<br />
					Términos y condiciones
				</u>
			</a>
			<a className="linkpopup" onClick={() => setPolitica(true)}>
				<u>
					<br />
					Políticas de privacidad
				</u>
			</a>
		</>
	);
}

export default Footer;
