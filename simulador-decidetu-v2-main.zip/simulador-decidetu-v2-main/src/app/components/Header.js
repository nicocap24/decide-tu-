import React from 'react';
import logo from '../assets/images/logo_pensionfi.jpeg';

const Header = () => {
	return (
		<>
			<style jsx>{`
				.img {
					aspect-ratio: 5.26;
					max-width: 100%;
					object-fit: cover;
					object-position: center;
					width: 145px;
					margin-left: 74px;
				}

				@media (max-width: 991px) {
					.img {
						margin-left: 10px;
					}
				}
			`}</style>

			<img loading="lazy" src={logo} className="img" alt="Logo Pensión Fi" />
		</>
	);
};

export default Header;
