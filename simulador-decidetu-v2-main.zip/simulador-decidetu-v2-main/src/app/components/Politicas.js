import React from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

const Politicas = ({ terminos, setTerminos }) => {
	const handleClose = () => setTerminos(false);
	return (
		<div className="modal_container">
			<Modal show={terminos} onHide={handleClose} animation={false}>
				<Modal.Header closeButton>
					<Modal.Title></Modal.Title>
				</Modal.Header>
				<Modal.Body>
					<h3 className="text-center">
						<strong>Políticas de privacidad</strong>
					</h3>
					<p>
						La sociedad PENSION FINANCE SPA (en adelante la “Sociedad”), RUT
						N°77.205.067-4, con domicilio principal en la ciudad de Santiago de
						Chile, es titular de la página web https://www.decidetu.cl/ (en
						adelante la “Web”). Las presentes Políticas de Privacidad (en
						adelante, las “Políticas”) regulan el tratamiento de datos
						personales realizado por la Web. Por el solo hecho de hacer uso de
						la Web, se entenderá que el Usuario ha leído, comprende y acepta
						esta Política de Privacidad y que es una persona con capacidad
						suficiente para contratar y obligarse conforme a la legislación de
						Chile.
					</p>
					<ol>
						<li>
							<strong>ÁMBITO DE APLICACIÓN.</strong>
							<p>
								Esta Política de Privacidad regula desde la recopilación, hasta
								la eliminación de los datos personales de los Usuarios de la
								Web. En consecuencia, su aplicación está circunscrita a dicha
								información denominada como “Datos Personales” de conformidad
								con la definición de la Ley 19.628 Sobre Protección de la Vida
								Privada, en lo sucesivo únicamente la “Ley”. De conformidad con
								lo mencionado en los T&amp;C de la Web, los Datos Personales se
								circunscriben únicamente al correo electrónico que el Usuario
								puede ingresar, para efectos de suscribirse al boletín de
								noticias. Los demás datos que solicita el simulador, no son
								tratados como Datos Personales, sino que son Datos Estadísticos
								de conformidad con la referida Ley. La Sociedad reconoce la
								relevancia de la protección de los Datos Personales, por lo que
								trata esta información con especial cuidado, orientando su
								actuar en respecto a estas materias en la Ley Sobre Protección
								de la Vida Privada y la Constitución Política de la República de
								Chile.
							</p>
						</li>
						<li>
							<strong>CONSENTIMIENTO Y FINALIDAD DEL TRATAMIENTO.</strong>
							<p>
								La Sociedad únicamente recolecta el correo electrónico de sus
								Usuarios, siendo el único Dato Personal que es tratado por esta.
								El Usuario por el hecho de ingresar su correo electrónico en la
								casilla de suscripción opcional al boletín de noticias, acepta
								esta Política y consiente expresamente en el tratamiento de su
								correo electrónico con el fin de cumplir con la finalidad,
								correspondiente a la entrega de comunicaciones de la Web, en las
								que se incluyen noticias subidas a la Web e informaciones sobre
								actualizaciones del Simulador. Todos los Datos Personales
								recopilados podrán ser eliminados y el consentimiento revocado
								en los casos en que el Usuario así lo solicite mediante una
								comunicación de conformidad con la cláusula de COMUNICACIONES de
								esta Política de Privacidad. Los Datos Personales así
								recolectados serán siempre tratados conforme a la legislación
								aplicable en materia de Protección de Datos. No se venderán los
								Datos Personales de los Usuarios a otros terceros, sin
								consentimiento del Usuario. Los Datos Personales serán
								eliminados cuando la finalidad por la que fueron recolectados
								hubiere caducado.
							</p>
						</li>
						<li>
							<strong>PERIODO DE TRATAMIENTO DE DATOS PERSONALES.</strong>
							<p>
								La Sociedad mantendrá los Datos Personales del Usuario en su
								poder durante todo el tiempo que permita la normativa vigente y
								siempre que el Usuario no hubiere ejercido sus derechos en el
								sentido de eliminarlos o de revocar las autorizaciones.
							</p>
						</li>
						<li>
							<strong>ACLARACIÓN DE TRATAMIENTO DE DATOS ESTADÍSTICOS.</strong>
							<p>
								La Sociedad realiza el tratamiento de Datos Estadísticos, los
								que no se encuentran sujetos a lo estipulado en la Ley 19.628
								Sobre Protección de la Vida Privada, puesto que, el simulador
								recopila la información que le es cargada. Con todo, aquella
								información no es considerada de carácter personal, ya que no se
								vincula con persona alguna. Al respecto, la Sociedad declara que
								no vincula los datos del Simulador con el correo electrónico que
								el Usuario pueda aportar para la suscripción al boletín de
								noticias, puesto que, los datos del simulador pueden ser
								ficticios, hipotéticos o incluso imposibles y se le permite a
								los Usuarios realizar todas las simulaciones que de buena fe
								deseen realizar para conseguir los fines educativos e
								informativos que tiene la Web, La Sociedad trata los Datos
								Estadísticos, con el fin de generar métricas que permitan medir
								las diversas situaciones que más generan duda en la población o
								que resultan simuladas con mayor frecuencia por los Usuarios, lo
								que le permitirá aportar con informativos más detallados y le
								permitirá ofrecer más funciones o mejorar las existentes. La
								Sociedad toma estos datos únicamente como simulaciones de
								escenarios teóricos, por lo que en ningún caso obliga a los
								Usuarios a ingresar información real. De igual forma, no se
								solicitan datos que permitan corroborar que la información
								aportada es real, por lo que, aun en caso de serlo, esa
								información es tratada como información ficticia o hipotética
								para efectos de simular diversas situaciones.
							</p>
						</li>
						<li>
							<strong>TRANSFERENCIA DE DATOS PERSONALES.</strong>
							<p>
								Para el desarrollo de su actividad, la Sociedad, mantiene
								relaciones comerciales con distintos proveedores, que le
								facilitan infraestructura necesaria para la Web, especialmente
								en cuanto al hosting de la Web, lo que puede provocar o
								constituir una transferencia de datos. Siendo así, la Sociedad
								elige cuidadosamente a sus proveedores para que la información
								personal se mantenga en adecuado resguardo, cuidando que en la
								medida de lo posible estos datos se almacenen en sus servidores,
								pero que eso no implique que los proveedores puedan acceder a
								ellos. En este sentido, el Usuario consiente en la transferencia
								de sus Datos Personales a los proveedores de servicios
								estructuralmente necesarios para la Web, entre los que se
								encuentran, servicios de almacenamiento en la nube; hosting; y,
								en general cualquier otro que, sin él no serían posibles las
								funciones indicadas en los T&amp;C de la Web o aquellas
								funciones solo operarían de forma imperfecta.
							</p>
						</li>
						<li>
							<strong>SEGURIDAD DE LA INFORMACIÓN</strong>
							<p>
								La Sociedad, actuando de buena fe, considera que los Datos
								Personales, es decir, los correos electrónicos aportados por los
								Usuarios, son veraces, y que, a su vez, estos han sido
								entregados de buena fe por parte del titular de los datos. Por
								lo que, no es responsable por cualquier infracción que derive de
								la alteración, mal uso, ilicitud, ilegitimidad, usurpación de
								identidad, aporte de correo electrónico ajeno o infracciones
								similares que puedan ocurrir con ocasión de la entrega de
								información por parte de un Usuario. Por otra parte, la
								Sociedad, realizará los esfuerzos necesarios para la protección
								de los datos de los Usuarios de la Plataforma. Toda brecha de
								seguridad que afecte a los Datos Personales de cada Usuario será
								informada por la Sociedad en un plazo razonable para la
								tranquilidad de sus Usuarios.
							</p>
						</li>
						<li>
							<strong>DERECHOS DEL USUARIO.</strong>
							<p>
								Todo Usuario de la Web puede ejercer los derechos que le
								confiere la Ley respecto de sus Datos Personales. En este
								apartado se realizará un breve resumen, sólo con carácter
								ilustrativo, respecto de los derechos que tienen los Usuarios y
								la forma que tienen para acceder a ellos:
							</p>
							<ul>
								<li>
									<strong>Acceso: </strong>
									<p>
										Solicitar información sobre sus datos, su origen,
										destinatarios y finalidad del tratamiento.
									</p>
								</li>
								<li>
									<strong>Rectificación: </strong>
									<p>
										Actualizar o corregir datos inexactos o desactualizados.
									</p>
								</li>
								<li>
									<strong>Eliminación: </strong>
									<p>
										Pedir la supresión de datos cuando su tratamiento no tenga
										fundamento legal o esté caduco.
									</p>
								</li>
								<li>
									<strong>Bloqueo: </strong>
									<p>
										Limitar el tratamiento de datos dudosos en cuanto a su
										veracidad o calidad.
									</p>
								</li>
								<li>
									<strong>Oposición: </strong>
									<p>
										Rechazar el uso de sus datos para fines de marketing,
										estudios de mercado o encuestas.
									</p>
								</li>
							</ul>
							<p>
								Sin perjuicio de la numeración en el resumen precedente, el
								Usuario puede hacer valer todos los derechos que la Ley le
								confiere respecto de sus Datos Personales. El ejercicio de los
								derechos que la Ley le confiere será siempre gratuito para el
								Usuario y podrá acceder a ellos mediante comunicación conforme a
								la cláusula de COMUNICACIONES de esta Política, dirigida a la
								Sociedad con el objetivo de hacer valer cualquiera de los
								derechos que detenta el titular de Datos Personales de
								conformidad con la Ley. El Usuario podrá revocar el
								consentimiento (y en consecuencia ejercer su derecho a la
								eliminación) respecto del tratamiento de Datos Personales a
								través del mismo mecanismo descrito en el párrafo anterior. Con
								todo, los derechos de los Usuarios tienen como límite la misma
								Ley 19.628 Sobre Protección de la Vida Privada, en particular en
								su artículo 15. La Sociedad, por su parte, se compromete a
								respetar dicho límite.
							</p>
						</li>
						<li>
							<strong>MODIFICACIÓN</strong>
							<p>
								La Sociedad podrá modificar esta Política de Privacidad en el
								momento en que estime necesario, en cuyo caso, publicará la
								nueva versión en la Web.
							</p>
						</li>
						<li>
							<strong>VIGENCIA</strong>
							<p>
								Esta Política de Privacidad entra en vigencia a partir de la
								fecha de su publicación y se mantendrá vigente hasta que se
								publique una nueva versión que la reemplace.
							</p>
						</li>
						<li>
							<strong>COMUNICACIONES</strong>
							<p>
								La Sociedad pone a disposición de sus Usuarios el siguiente
								correo electrónico de comunicación: nico@pensionfi.com, mediante
								el cual los Usuarios podrán comunicarse para hacer valer los
								derechos que la ley les confiere, en especial en cuanto a
								Protección de Datos Personales.
							</p>
						</li>
					</ol>
				</Modal.Body>
				<Modal.Footer>
					<Button
						variant="Primary"
						className="btn btn-outline-success"
						onClick={handleClose}
					>
						Cerrar
					</Button>
				</Modal.Footer>
			</Modal>
		</div>
	);
};

export default Politicas;
