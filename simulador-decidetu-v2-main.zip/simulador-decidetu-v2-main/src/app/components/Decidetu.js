import * as React from 'react';

function Decidetu() {
	return (
		<>
			<section className="decide-tu" id="#top">
				<div className="content-wrapper">
					<div className="content-container">
						<div className="image-column">
							<img
								loading="lazy"
								src="https://cdn.builder.io/api/v1/image/assets/TEMP/fd6a1249d7f8e63cc6b4a4bbbbaff96dde91218556fe84b6433f43105a4a4b2d?apiKey=fa97ba7e80824a5c857b3c5ffc449f99&"
								className="decide-tu-image"
								alt="Decide tu"
							/>
						</div>
						<div className="text-column">
							<div className="text-content">
								{/* <h2 className="title">¡DECIDE TÚ!</h2> */}
								<p className="description">
									¿Sabes cómo la reforma de pensiones impacta tu pensión?
									<br />
									<br />
									Hoy ahorramos el 10% de nuestro sueldo para financiar nuestra
									futura pensión. El proyecto de reforma propone aumentar en 6%
									la cotización individual de cada trabajador con cargo al
									empleador. Si de ese 6%, la mitad, es decir, 3% se destinara a
									financiar <span id="form_simular">el Seguro Social </span>y
									solo el 3% restante se destinara a tu cuenta individual ¿Cómo
									impactaría tu pensión futura?
								</p>
							</div>
						</div>
					</div>
				</div>
			</section>
			<div className="bg-danger"></div>
		</>
	);
}

export default Decidetu;
