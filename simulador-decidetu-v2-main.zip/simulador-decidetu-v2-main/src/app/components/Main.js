import React from 'react';

const Main = ({ repartir }) => {
	return (
		<>
			<main className="main-container">
				<div className="content-wrapper">
					<article className="article-column">
						<header className="article-header">
							<h1 className="article-title">
								NUEVA APP AYUDA A CONOCER SI LA REFORMA PREVISIONAL CONVIENE
							</h1>
							<p className="article-description">
								La Calculadora Previsional es un simulador para comprobar si la
								propuesta del seguro social de la reforma de pensiones es o no
								beneficiosa para los cotizantes.
								<br />
								<br />
								El proyecto es desarrollado por Pensión Fi y busca convertirse
								en viral para luego ser foco de los medios de comunicación
								durante el periodo en que se esté discutiendo la reforma en el
								Senado.
								<br />
								<br />
								<br />
							</p>
						</header>
					</article>
					<aside className="image-column">
						<img
							src="https://cdn.builder.io/api/v1/image/assets/TEMP/4bd82f007370e88c59fe7a5cecb93cb70f85adf8bcbcd496b594f347122224c5?apiKey=fa97ba7e80824a5c857b3c5ffc449f99&"
							alt=""
							className="article-image"
						/>
					</aside>
				</div>
			</main>
			<style jsx>{`
				.main-container {
					align-self: center;
					margin-top: 17px;
					width: 100%;
					max-width: 1278px;
				}

				@media (max-width: 991px) {
					.main-container {
						max-width: 100%;
					}
				}

				.content-wrapper {
					display: flex;
					gap: 20px;
				}

				@media (max-width: 991px) {
					.content-wrapper {
					}
				}

				.article-column {
					width: 68%;
					margin-left: 0;
				}

				@media (max-width: 991px) {
					.article-column {
						width: 100%;
					}
				}

				.article-header {
					margin-top: 32px;
					color: #000;
				}

				@media (max-width: 991px) {
					.article-header {
						max-width: 100%;
						margin-top: 40px;
					}
				}

				.article-title {
				}

				@media (max-width: 991px) {
				}

				.article-description {
					letter-spacing: 0.48px;
					margin-top: 63px;
					font: 400 24px Alegreya Sans, -apple-system, Roboto, Helvetica,
						sans-serif;
				}

				@media (max-width: 991px) {
					.article-description {
						max-width: 100%;
						margin-top: 40px;
					}
				}

				/* .image-column {
					width: 32%;
					margin-left: 20px;
				}

				@media (max-width: 991px) {
					.image-column {
						width: 100%;
					}
				} */

				.article-image {
					aspect-ratio: 0.9;
					object-fit: auto;
					object-position: center;
					width: 100%;
				}

				@media (max-width: 991px) {
				}
			`}</style>
		</>
	);
};

export default Main;
