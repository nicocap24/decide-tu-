import React from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

const ModalBeneficioSsp = ({ infoBeneficioSsp, setInfoBeneficioSsp }) => {
	const handleClose = () => setInfoBeneficioSsp(false);
	return (
		<div className="modal_container">
			<Modal show={infoBeneficioSsp} onHide={handleClose} animation={false}>
				<Modal.Header closeButton>
					<Modal.Title></Modal.Title>
				</Modal.Header>
				<Modal.Body>
					<h3 className="text-center">
						<strong>
							¿Qué significa que 3% de cotización se destine un Seguro Social?
						</strong>
						<p>
							El proyecto de Reforma de Pensiones del Gobierno del Presidente
							Gabriel Boric propone, entre otras cosas, que 3% (del 6%) de
							cotización adicional se destine a un Seguro Social Previsional.
							Este porcentaje financiaría una garantía correspondiente a 0,1 UF
							por año cotizado, llegando a un máximo de 3 UF (Es decir, 30 años
							cotizados). Además, entregaría una compensación por diferencias de
							expectativa de vida, en beneficio de las mujeres y un complemento
							por labores de cuidados a terceros.
						</p>
					</h3>
				</Modal.Body>
				<Modal.Footer>
					<Button
						variant="Primary"
						className="btn btn-outline-success"
						onClick={handleClose}
					>
						Cerrar
					</Button>
				</Modal.Footer>
			</Modal>
		</div>
	);
};

export default ModalBeneficioSsp;
