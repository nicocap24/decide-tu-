import React, { useState, useEffect } from 'react';
import { Rating } from 'react-simple-star-rating';
import { Form } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import useRecaptchaV3 from '../hooks/useRecaptchaV3';

const RatingComponent = ({ keyTabla }) => {
	const [rating, setRating] = useState(0); // initial rating value
	const [isDisabled, setIsDisabled] = useState(true); // initial disabled state
	const [mail, setMail] = useState('');
	const [nombre, setNombre] = useState('');
	const [msg, setMsg] = useState('');
	const [suscribe, setSuscribe] = useState(false);
	const email_error = document.getElementById('email_error');
	const msg_error = document.getElementById('msg_error');
	const nombre_error = document.getElementById('nombre_error');
	const text = document.getElementById('rating_success');
	const starsContainer = document.getElementById('stars_container');
	const specialChars = /[`!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~]/;
	const containNumbers = /\d/;
	const emailFormat =
		/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
	const executeRecaptcha = useRecaptchaV3({
		SITE_KEY: process.env.REACT_APP_DECIDETU_CAPTCHA_SITEKEY,
	});
	let emptyField = false;
	useEffect(() => {
		if (keyTabla) {
			setIsDisabled(false);
		} else {
			setIsDisabled(true);
		}
	}, [keyTabla]);

	// Catch Rating value con el movimiento del mouse
	const onPointerMove = value => {
		if (!isDisabled) {
			setRating(value);
		}
	};

	// process.env.REACT_APP_API_EVALUAR_URL
	const handleRating = async e => {
		e.preventDefault();
		// Obtener la fecha y hora actuales en milisegundos desde el epoch
		const now = Date.now();

		// Crear un objeto Date a partir del timestamp actual
		const date = new Date(now);

		// Especificar la región y opciones de formato para Chile
		const options = {
			year: 'numeric',
			month: '2-digit',
			day: '2-digit',
			hour: '2-digit',
			minute: '2-digit',
			second: '2-digit',
			timeZone: 'America/Santiago', // Zona horaria específica de Chile
			hour12: false, // Utiliza formato de 24 horas
		};

		// Crear el formateador de fecha y hora para la región especificada
		const dateTimeFormat = new Intl.DateTimeFormat('es-CL', options);

		// Formatear la fecha
		const formattedDate = dateTimeFormat.format(date);
		if (!isDisabled) {
			email_error.classList.add('d-none');
			msg_error.classList.add('d-none');
			nombre_error.classList.add('d-none');
			if (!mail || !emailFormat.test(mail)) {
				email_error.classList.remove('d-none');
				emptyField = true;
			}
			if (!msg) {
				msg_error.classList.remove('d-none');
				emptyField = true;
			}
			if (!nombre || specialChars.test(nombre) || containNumbers.test(nombre)) {
				nombre_error.classList.remove('d-none');
				emptyField = true;
			}
			const recaptchaToken = await executeRecaptcha(
				'EnvianosTusComentariosYLosRecibiremosConGusto'
			);
			if (mail && emailFormat.test(mail) && msg) {
				const apiUrl = process.env.REACT_APP_API_URL || window.location.origin;
				//console.log(`${apiUrl}/sndRating`);
				!emptyField &&
					(await fetch(`${apiUrl}/sndRating`, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json',
						},
						body: JSON.stringify({
							id: keyTabla,
							fechaPeticion: formattedDate, // Agregar la fecha actual
							nombre: nombre,
							mail: mail,
							rating: rating,
							suscribirse: suscribe ? 'Si' : 'No',
							recaptchaToken: recaptchaToken,
							msg: msg,
						}),
					}).then(() => {
						starsContainer.classList.add('starts-avoid');
						text.classList.remove('d-none');
					}));
			}
		}
	};
	useEffect(() => {
		console.log(rating);
	}, [rating]);

	return (
		<div className="mb-4 text-center p-2 resultado_inner">
			<h4 className="h4 ">¿Qué te pareció este simulador?</h4>
			<div id="stars_container">
				<Rating
					onPointerMove={onPointerMove}
					ratingValue={rating}
					size={50}
					label
					transition
					fillColor="orange"
					emptyColor="#ffe799"
					className="" // Will remove the inline style if applied
				/>
			</div>

			<p>¿Opiniones, feedback, reclamos, felicitaciones?</p>
			<Form onSubmit={handleRating}>
				<Form.Group className="mb-3 " controlId="exampleForm.ControlInput1">
					<Form.Control
						onChange={e => setNombre(e.target.value)}
						value={nombre}
						type="text"
						placeholder="Ingrese su nombre"
						className="mb-2"
					/>
					<span id="nombre_error" className="text-danger d-none">
						*Este campo solo puede tener letras
					</span>
					<Form.Control
						onChange={e => setMail(e.target.value)}
						value={mail}
						type="email"
						placeholder="nombre@ejemplo.com"
						className="mb-2"
					/>
					<span id="email_error" className="text-danger d-none">
						*Inserte formato correcto de email
					</span>
				</Form.Group>
				<Form.Group className="mb-3" controlId="Escriba su mensaje aquí">
					<Form.Control
						onChange={e => setMsg(e.target.value)}
						as="textarea"
						rows={3}
						value={msg}
						placeholder="Déjanos tus comentarios acá"
					/>
					<span id="msg_error" className="text-danger d-none">
						*Escriba un mensaje
					</span>
					<div className="d-flex">
						<Form.Check
							onClick={e => setSuscribe(e.target.checked)}
							style={{ marginRight: '10px' }}
						/>
						<p>Deseo enterarme de los próximos updates a la reforma. </p>
					</div>
				</Form.Group>

				<Button
					variant="secundary"
					type="submit"
					className={isDisabled ? 'submit-disabled' : 'bg-success text-white'}
				>
					Enviar
				</Button>
				<p id="rating_success" className="text-success d-none">
					¡Gracias por su mensaje!
				</p>
			</Form>
		</div>
	);
};

export default RatingComponent;
