import React from 'react';

const Menu = () => {
	return (
		<nav className="col-12 position-fixed top-0 p-4 menu">
			<a href="#top" className="ir_top">
				<h1 className="title">¡DECIDE TÚ!</h1>
			</a>
			<div className="ir_simulador">
				<a href="#form_simular">¡Simula y comparte!</a>
			</div>
		</nav>
	);
};

export default Menu;
