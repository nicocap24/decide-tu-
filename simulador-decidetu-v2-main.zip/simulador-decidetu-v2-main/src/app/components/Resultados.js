import React from 'react';

const Resultados = ({
	beneficioCI,
	beneficioSsp,
	setInfoBeneficioCi,
	setInfoBeneficioSsp,
	capIndividual,
	setCapIndividual,
	cotizacionSSp,
}) => {
	const convertedBenefisiosssp = Number(beneficioSsp).toLocaleString('es-CL', {
		style: 'currency',
		currency: 'CLP',
	});
	const convertedBeneficioCI = Number(beneficioCI).toLocaleString('es-CL', {
		style: 'currency',
		currency: 'CLP',
	});
	return (
		<div className="d-flex flex-column ">
			<div className="d-flex resultado g-4 ">
				<div className="text-center position-relative p2 resultado_inner">
					<span onClick={() => setInfoBeneficioSsp(true)}>
						<strong className="position-absolute start-0 top-0 text-white start-0 top-0 px-2 info-symbol bg-info">
							!
						</strong>
					</span>
					<p className="beneficios-titulo mt-4">
						Si tu 3% de cotización adicional se destina al Seguro Social tu
						pensión aumentaría en:
					</p>{' '}
					<h2 className="beneficios-numero">{convertedBenefisiosssp}</h2>
				</div>
				<p className="text-center my-auto h6">
					Veamos qué pasaría si es que ese 3% adicional fuera directamente a tu
					cuenta de capitalización individual:
				</p>
				<div className="text-center position-relative p2 resultado_inner">
					<span onClick={() => setInfoBeneficioCi(true)}>
						<strong className="position-absolute text-white end-0 top-0 px-2 info-symbol bg-info">
							!
						</strong>
					</span>

					{/* <p className="beneficios-titulo">
						Si tu 3% de cotización adicional se destina a tu cuenta de
						capitalización individual tu pensión aumentaría en:
					</p>{' '} */}
					{capIndividual ? (
						<h2 className="beneficios-numero">{convertedBeneficioCI}</h2>
					) : (
						<h2
							className="beneficios-numero --modif-color"
							onClick={() => setCapIndividual(true)}
						>
							Ver aquí
						</h2>
					)}
				</div>
			</div>
			<h3 className="text-center fw-bold mt-5">Explicación</h3>
			<p className="col-12 col-md-5 mx-auto text-center">
				Si un 3% de cotización extra se destina al Seguro Social, recibirás un
				beneficio de{' '}
				<strong>
					{Number(beneficioSsp).toLocaleString('es-CL', {
						style: 'currency',
						currency: 'CLP',
					})}
				</strong>
				. En cambio, si destinas el mismo 3% de cotización extra a
				Capitalización Individual, recibirás un beneficio de{' '}
				<strong>
					{Number(beneficioCI).toLocaleString('es-CL', {
						style: 'currency',
						currency: 'CLP',
					})}
				</strong>
			</p>
		</div>
	);
};

export default Resultados;
