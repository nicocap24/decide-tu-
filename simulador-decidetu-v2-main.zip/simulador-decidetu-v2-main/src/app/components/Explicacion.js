import * as React from 'react';
import nube from '../assets/images/nube.png';
import pc from '../assets/images/pc.png';
import questionmark from '../assets/images/question_mark.png';
import gFlecha from '../assets/images/grafico_flecha.png';

const QuestionTitle = ({ children }) => (
	<h2 className="question-title">{children}</h2>
);

const QuestionImage = ({ src, alt }) => (
	<img className="question-image" src={src} alt={alt} loading="lazy" />
);

const QuestionImageWithTitle = ({ imageSrc, imageAlt, title }) => (
	<div className="question-image-with-title">
		<QuestionImage src={imageSrc} alt={imageAlt} />
		<QuestionTitle>{title}</QuestionTitle>
	</div>
);

const Paragraph = ({ children }) => <p className="paragraph">{children}</p>;

const questions = [
	{
		title: '¿Qué es el 6% de cotización adicional?',
		imageSrc:
			'https://cdn.builder.io/api/v1/image/assets/TEMP/d31a4f6994f43297a51e7dcb9d2d35ccf131755f6e76e9e8f452174997c70a74?apiKey=fa97ba7e80824a5c857b3c5ffc449f99&',
		imageAlt:
			"Imagen relacionada con la pregunta '¿Qué es el 6% de cotización adicional?'",
		paragraphs: [
			'El proyecto de ley de Reforma de Pensiones, presentado por el Gobierno de Presidente Gabriel Boric, plantea que la cotización individual de cada trabajador aumente en un 6%, con cargo al empleador. Esto significa que las cotizaciones para pensión pasarían a representar un 16% de la remuneración bruta.',
			'El proyecto de ley de Reforma de Pensiones, presentado por el Gobierno de Presidente Gabriel Boric, plantea que la cotización individual de cada trabajador aumente en un 6%, con cargo al empleador. Esto significa que las cotizaciones para pensión pasarían a representar un 16% de la remuneración bruta.',
		],
	},
	{
		title:
			'¿Qué significa que 6% de cotización adicional se destine a cotización individual?',
		imageSrc:
			'https://cdn.builder.io/api/v1/image/assets/TEMP/4bac8694bd4e6719656b4f967d3865ef1ba090830f906e72245c5bd2f93b6cb8?apiKey=fa97ba7e80824a5c857b3c5ffc449f99&',
		imageAlt:
			"Imagen relacionada con la pregunta '¿Qué significa que 6% de cotización adicional se destine a cotización individual?'",
		paragraphs: [
			'Esto se traduce en que la cotización actual del 10% así como el aumento de ella en un 6% se destinarían a ahorro para pensión en la cuenta individual de cotizaciones obligatorias de cada trabajar. De esta manera, el Pilar Contributivo del Sistema de Pensiones chileno consideraría una cotización de 16%.',
		],
	},
	{
		title: 'Quién está tras la Calculadora Previsional?',
		imageSrc:
			'https://cdn.builder.io/api/v1/image/assets/TEMP/a9928c333b16ba6a928694c5ed4303078c8f30aad13645375e1068159a6485c8?apiKey=fa97ba7e80824a5c857b3c5ffc449f99&',
		imageAlt:
			"Imagen relacionada con la pregunta 'Quién está tras la Calculadora Previsional?'",
	},
];

function Explicacion() {
	return (
		<>
			<div className="container mt-5 explicacion-container">
				<div className="explicacion-card ">
					<div className="explicacion-card__header mb-4">
						<h6 className=" explicacion-titulo">
							¿En qué consiste la reforma previsional?
						</h6>
						<div className="">
							<img src={nube} alt="nube" />
						</div>
					</div>
					<p className="explicacion-text">
						El proyecto de ley de Reforma de Pensiones, presentado por el
						Gobierno del Presidente Gabriel Boric, propone aumentar en un 6% la
						cotización individual de cada trabajador con cargo al empleador.
						Esto significa que las cotizaciones para pensión pasarían a
						representar un 16% de la remuneración bruta.
					</p>
				</div>
				{/* <div className="explicacion-card ">
					<div className="explicacion-card__header mb-4">
						<h6 className="explicacion-titulo">
							¿Quién está tras la Calculadora Previsional?
						</h6>
						<div className="">
							<img src={pc} alt="pc" />
						</div>
					</div>
					<p className="explicacion-text">
						El proyecto de Reforma de Pensiones del Gobierno del presidente
						Gabriel Boric propone, entre otras cosas, que el 6% de cotización
						adicional se destine a un Seguro Social. Este financiaría el aumento
						de la pensión en 0,1 UF por año cotizado, por un máximo de 3 UF.
						Además, entregaría un complemento por labores de cuidados a terceros
						y la compensación por diferencias de expectativa de vida, en
						beneficio de las mujeres.
					</p>
				</div> */}
			</div>
			<div className="container explicacion-container">
				<div className="explicacion-card ">
					<div className="explicacion-card__header mb-4">
						<div className="questions">
							<img src={questionmark} alt="question marks" />
						</div>
						<h6 className=" explicacion-titulo">
							¿Qué significa que 3% de cotización se destine un Seguro Social?
						</h6>
					</div>
					<p className="explicacion-text">
						El proyecto de Reforma de Pensiones del Gobierno del Presidente
						Gabriel Boric propone, entre otras cosas, que 3% (del 6%) de
						cotización adicional se destine a un Seguro Social Previsional. Este
						porcentaje financiaría una garantía correspondiente a 0,1 UF por año
						cotizado, llegando a un máximo de 3 UF (Es decir, 30 años
						cotizados). Además, entregaría una compensación por diferencias de
						expectativa de vida, en beneficio de las mujeres y un complemento
						por labores de cuidados a terceros.
					</p>
				</div>
				<div className="explicacion-card ">
					<div className="explicacion-card__header mb-4">
						<div className="">
							<img src={gFlecha} alt="gráfico de flecha" />
						</div>
						<h6 className=" explicacion-titulo">
							¿Qué significa que 3% de cotización se destine a la cuenta
							individual?
						</h6>
					</div>
					<p className="explicacion-text">
						El proyecto de ley propone que 3% (del 6%) de cotización adicional
						se destine a la cuenta de capitalización individual de los
						trabajadores. De este 3%, el 2,1% iría directamente a la cuenta de
						los afiliados y un 0,9% se repartiría de acuerdo al ingreso promedio
						de los cotizantes del mes.
					</p>
				</div>
			</div>
		</>
	);
}

export default Explicacion;
