'use client';
import Image from 'next/image';

import { useRouter } from 'next/navigation';

// components
import Navbar from './components/Navbar';
import NewFooter from './components/NewFooter';

// framer motion for animations
import { motion } from 'framer-motion';

export default function Home() {
  const router = useRouter();

  return (
    <>
      <main className="flex min-h-screen flex-col items-center bg-white">
        <Navbar />

        <div className="relative flex flex-col gap-[10px] items-center bg-white text-center w-11/12 h-screen max-h-screen md:w-full ">
          <motion.h2
            className="text-[35px] font-quasimoda font-bold text-secondary"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: 'easeOut' }}
          >
            Es TU pensión y TÚ decides
            <br /> qué es mejor para ti.
          </motion.h2>

          <p className="text-[#757575] text-[18px] font-quasimoda">
            Los políticos llevan +15 años debatiendo la reforma de pensiones.
            <br /> Es hora de que abramos el debate para todos.
          </p>

          <Image src="/assets/landing/phone.png" alt="pension" width={400} height={100} />
          <button
            className="bg-primary py-2 px-16 mx-auto rounded-[70px] hover:bg-primary-with-opacity font-quasimoda"
            onClick={() => {
              router.push('/simulacion');
            }}
          >
            <p className="text-black font-quasimoda font-bold text-[20px]">descúbrelo 👀</p>
          </button>
        </div>
        <div className="text-center">
          <p className="text-black font-quasimoda font-bold text-[20px]">¿Cómo funciona?</p>
          <div className="flex justify-between w-96">
            <div className="w-20">
              <p className="bg-primary p-6 rounded-full text-black font-quasimoda">1</p>
              <p className="font-quasimoda">Ingresa tus datos</p>
            </div>

            <div className="w-20">
              <p className="bg-primary p-6 rounded-full text-black font-quasimoda">2</p>
              <p className="font-quasimoda">Compara</p>
            </div>

            <div className="w-20">
              <p className="bg-primary p-6 rounded-full text-black font-quasimoda">3</p>
              <p className="font-quasimoda">Opina</p>
            </div>
          </div>
        </div>
        <NewFooter />
      </main>
    </>
  );
}
