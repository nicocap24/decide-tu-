import React from 'react';

import { FaXTwitter, FaFacebook } from 'react-icons/fa6';
import { IoLogoWhatsapp } from 'react-icons/io';
import { MdEmail } from 'react-icons/md';
import {
  WhatsappShareButton,
  EmailShareButton,
  TwitterShareButton,
  FacebookShareButton,
} from 'react-share';

type SocialProps = {
  bnsp: number;
  bci: number;
};

const Social: React.FC<SocialProps> = ({ bnsp, bci }) => {
  const DATA_SHARE = `Yo ya vi cómo me afecta la reforma previsional 😱
Mi beneficio sería de: ${Number(bnsp).toLocaleString('es-CL', {
    style: 'currency',
    currency: 'CLP',
  })} con Seguro Social y de: ${Number(bci).toLocaleString('es-CL', {
    style: 'currency',
    currency: 'CLP',
  })} con Capitalización Individual.	
Descubre tus resultados acá:
#DecideTU
`;

  const URL_SITE = 'https://www.decidetu.cl/';

  return (
    <div className="flex flex-col justify-center items-center self-center mt-3 gap-[10px]">
      <div>
        <h6 className="text-center font-quasimoda">Comparte tus resultados acá:</h6>
      </div>

      <div className="flex gap-x-2 ">
        <WhatsappShareButton title={DATA_SHARE} separator=" " url={URL_SITE}>
          <div>
            <IoLogoWhatsapp className="text-4xl" />
          </div>
        </WhatsappShareButton>

        <TwitterShareButton url={URL_SITE} title={DATA_SHARE}>
          <div>
            <FaXTwitter className="text-4xl" />
          </div>
        </TwitterShareButton>

        <EmailShareButton
          subject="Decide Tú: Reforma de Pensiones"
          body={DATA_SHARE}
          separator=" "
          url={URL_SITE}
        >
          <div>
            <MdEmail className="text-4xl" />
          </div>
        </EmailShareButton>
        <FacebookShareButton url={URL_SITE}>
          <div>
            <FaFacebook className="text-3xl" />
          </div>
        </FacebookShareButton>
      </div>
    </div>
  );
};

export default Social;
