/* eslint-disable react/prop-types */
import { useSwiper } from 'swiper/react';
import { useRouter } from 'next/navigation';

//import icons
import { RiArrowRightSLine } from 'react-icons/ri';

interface SwiperNextButtonsProps {
  index: number;
  nombre: string;
  rentaImponible: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
  setCalculate: React.Dispatch<React.SetStateAction<boolean>>;
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>;
}

const SwiperNextButtons: React.FC<SwiperNextButtonsProps> = ({
  index,
  nombre,
  rentaImponible,
  setStep,
  setCalculate,
  setIsLoading,
}) => {
  const swipe = useSwiper();

  const handleNext = () => {
    setIsLoading(true);
    setCalculate(true);
    setStep(2);
  };
  const handleStop = () => {
    console.log('mal');
    return;
  };

  return (
    <>
      {index < 7 ? (
        <button
          className="absolute w-11 h-11 bottom-0 right-0 z-[10000] rounded-full mb-2  bg-primary text-primario  flex items-center justify-center"
          onClick={() => swipe.slideNext()}
        >
          <RiArrowRightSLine className="text-3xl" />
        </button>
      ) : (
        <>
          <button
            onClick={nombre == '' || rentaImponible == 0 ? () => handleStop() : () => handleNext()}
            className={`absolute right-0 bottom-0 bg-primary z-[10000] p-3 w-100 mb-2 rounded-xl text-primario font-quasimoda text-[20px] font-bold ${
              nombre == '' || rentaImponible == 0
                ? 'cursor-not-allowed bg-green-200 text-gray-400'
                : ''
            }`}
          >
            ¡Ver resultados!
          </button>
        </>
      )}
    </>
  );
};

export default SwiperNextButtons;
