'use client';
import { useState, useEffect, useRef } from 'react';
import CurrencyInput from 'react-currency-input-field';
import html2canvas from 'html2canvas';
import { usePathname } from 'next/navigation';

//import calc functions
import calculaBonoExpectativaVida from './_calc/calculaBonoExpectativaVida';
import { calculaBonoCompensacionExpectativaVida } from './_calc/calculaBonoCompensacionExpectativaVida';
import { calculoBeneficioCI } from './_calc/calculoBeneficioCI';
import { calculoBeneficioSsp } from './_calc/calculoBeneficioSsp';

//Import react-icons
import { RiInformation2Line, RiMenu3Line, RiCloseLine } from 'react-icons/ri';

//import chart-js
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions,
} from 'chart.js';
import Social from './Social';
import Loader from './Loader';
import Calculos from './_modals/Calculos';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

type PensionChartProps = {
  nombre: string;
  edad: number;
  sexo: string;
  email: string;
  rentaImponible: number;
  anosCotizados: number;
  anosRestantes: number;
  setStep: React.Dispatch<React.SetStateAction<number>>;
  setEdad: React.Dispatch<React.SetStateAction<number>>;
  setSexo: React.Dispatch<React.SetStateAction<string>>;
  setAnosCotizados: React.Dispatch<React.SetStateAction<number>>;
  setAnosRestantes: React.Dispatch<React.SetStateAction<number>>;
  handleChangeRentaImponible: (newValue: string | undefined) => void;
  calculate: boolean;
  setCalculate: React.Dispatch<React.SetStateAction<boolean>>;
  isLoading: boolean;
  setIsLoading: React.Dispatch<React.SetStateAction<boolean>>;
};

export default function PensionChart({
  nombre,
  edad,
  sexo,
  email,
  rentaImponible,
  anosCotizados,
  anosRestantes,
  setEdad,
  setSexo,
  setAnosCotizados,
  setAnosRestantes,
  handleChangeRentaImponible,
  calculate,
  setCalculate,
  isLoading,
  setIsLoading,
}: PensionChartProps) {
  const barChartRef = useRef(null);

  //modal supuestos
  const [CalcExplanation, setCalcExplanation] = useState(false);

  //Calc variables
  const [valorUF, setValorUF] = useState(0);
  const [cnu, setCNU] = useState(0);
  const repartir = 0.06;
  const cotizacionSSp = 0.03;
  const tasaCIsobreSueldo = (repartir - cotizacionSSp) * 0.7;
  const tasaCIsobreSueldoPromedio = (repartir - cotizacionSSp) * 0.3;
  const [completoAntesEdadActual, setCompletoAntesEdadActual] = useState(0);
  const [faltaparaJubilacion, setFaltaparaJubilacion] = useState(0);
  const [beneficioCI, setBeneficioCI] = useState(0);
  const [beneficioSsp, setBeneficioSsp] = useState(0);
  const edadJubilacionF = 62;
  const edadJubilacionM = 65;
  const ingresoPromedio = 1100000;
  const rentabAnualFFPP = 0.04; // 4%
  const topeImponible = 122.6;

  //Evaluation states
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleExplanation = () => {
    setCalcExplanation(false);
  };

  //Set CNU amount
  useEffect(() => {
    if (sexo === 'M') {
      setCNU(14.7);
    } else if (sexo === 'F') {
      setCNU(18.2);
    } else {
      setCNU(0);
    }
    console.log('cnu');
  }, [sexo]);

  //Establecer jubilacion segun genero
  useEffect(() => {
    if (sexo === 'M') {
      setFaltaparaJubilacion(edadJubilacionM - edad);
    } else if (sexo === 'F') {
      setFaltaparaJubilacion(edadJubilacionF - edad);
    } else {
      setFaltaparaJubilacion(0);
    }
  }, [edad, edadJubilacionF, edadJubilacionM, sexo]);

  useEffect(() => {
    setCompletoAntesEdadActual(edad - 18);
  }, [edad]);

  //Get valorUf
  useEffect(() => {
    const fetchValorUF = async () => {
      try {
        const response = await fetch('https://mindicador.cl/api/uf');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        setValorUF(data.serie[0].valor);
      } catch (error) {
        console.error('There has been a problem with your fetch operation:', error);
      }
    };

    fetchValorUF();
  }, []);

  const resultBtn = async () => {
    setIsLoading(true);
    console.log('calculando');
    setIsMenuOpen(false);
    //Calc pafe
    const { pafe, acumuladoRestante, acumuladoCi } = calculaBonoExpectativaVida(
      edad,
      rentaImponible,
      tasaCIsobreSueldo,
      tasaCIsobreSueldoPromedio,
      anosCotizados,
      completoAntesEdadActual,
      anosRestantes,
      faltaparaJubilacion,
      ingresoPromedio,
      rentabAnualFFPP,
      cnu,
      sexo,
      edadJubilacionM,
      edadJubilacionF,
      valorUF,
      topeImponible,
      cotizacionSSp
    );

    //Calc bono compensacion expectativa de vida
    const bonoExpectativaVida = calculaBonoCompensacionExpectativaVida(pafe, valorUF);
    const ben_ci = calculoBeneficioCI(cnu, acumuladoCi);

    // calculo beneficio seguro social previsional
    const ben_ssp = calculoBeneficioSsp(
      cotizacionSSp,
      sexo,
      tasaCIsobreSueldo,
      anosCotizados,
      anosRestantes,
      valorUF,
      acumuladoRestante,
      cnu,
      bonoExpectativaVida,
      edad
    );
    setBeneficioCI(ben_ci);
    setBeneficioSsp(ben_ssp);
    // Obtener la fecha y hora actuales en milisegundos desde el epoch
    const now = Date.now();

    // Crear un objeto Date a partir del timestamp actual
    const date = new Date(now);

    // Especificar la región y opciones de formato para Chile
    const options = {
      year: 'numeric' as 'numeric',
      month: '2-digit' as '2-digit',
      day: '2-digit' as '2-digit',
      hour: '2-digit' as '2-digit',
      minute: '2-digit' as '2-digit',
      second: '2-digit' as '2-digit',
      timeZone: 'America/Santiago',
      hour12: false,
    };

    // Crear el formateador de fecha y hora para la región especificada
    const dateTimeFormat = new Intl.DateTimeFormat('es-CL', options);

    // Formatear la fecha
    const formattedDate = dateTimeFormat.format(date);

    const data = {
      nombre,
      email,
      edad,
      anosCotizados,
      anosRestantes,
      sexo,
      rentaImponible,
      beneficioCI: ben_ci,
      beneficioSsp: ben_ssp,
      fechaPeticion: formattedDate, // Agregar la fecha actual
    };

    await fetch('/api/simulation', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
      .then((res) => res.json())
      .then((r) => {
        console.log(r);
      })
      .finally(() => setIsLoading(false));
  };
  useEffect(() => {
    if (nombre == '') {
      setIsLoading(false);
      return;
    }
    if (calculate && valorUF > 0 && cnu > 0 && faltaparaJubilacion > 0) {
      resultBtn();
      setCalculate(false);
    }
  }, [calculate, valorUF, cnu, faltaparaJubilacion]);

  const data = {
    labels: ['Capitalización Individual', 'Seguro Social'],
    datasets: [
      {
        label: '',
        data: [beneficioCI, beneficioSsp],
        backgroundColor: ['#55F5BB', '#FF4A1C'],
      },
    ],
  };

  const options: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
        position: 'bottom' as const,
      },
    },
    scales: {
      x: {
        title: {
          display: false,
          text: 'Edad',
        },
        ticks: {
          font: {
            size: 16,
            family: 'Quasimoda',
          },
        },
      },
      y: {
        beginAtZero: true,
        min: 0,
        max: Math.ceil((Math.max(beneficioCI, beneficioSsp) + 10000) / 10000) * 10000,
        title: {
          display: true,
          text: 'Beneficio recibido',
          font: {
            size: 16,
            weight: 'bold',
            family: 'Quasimoda',
          },
        },
        ticks: {
          stepSize: 10000,
          font: {
            size: 12,
            family: 'Quasimoda',
          },
          callback: function (value: string | number) {
            if (Number.isInteger(value)) {
              return `$${value.toLocaleString()}`;
            }
            return null;
          },
        },
      },
    },
  };

  return (
    <>
      {/* Este loader inicia cuando se presiona el boton de calcular, y desaparece cuando se termina el fetch */}
      {isLoading && <Loader />}
      <div className="flex relative w-full md:w-10/12 mt-[20px] mb-[100px]">
        <div className="flex flex-col md:flex-row w-full relative md:min-h-[400px] md:justify-center items-center py-6 px-4 gap-x-[80px]">
          {/* Icono del menú de hamburguesa para vista móvil */}
          <div className="md:hidden flex justify-between items-center w-full p-4">
            <h3 className="text-xl text-black font-bold font-quasimoda">
              💸 Ajusta tus respuestas
            </h3>
            <button onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <RiCloseLine size={30} /> : <RiMenu3Line size={30} />}
            </button>
          </div>

          {/* configurations */}
          <div
            className={`${
              isMenuOpen ? 'block' : 'hidden'
            } md:block w-full md:w-1/3 h-fit bg-white flex flex-col items-center rounded-lg p-6 shadow-[0_0_10px_rgba(0,0,0,0.21)]`}
          >
            <div className="flex flex-col gap-y-4 w-full">
              <h3 className="text-xl text-black font-bold font-quasimoda hidden md:block">
                💸 Ajusta tus respuestas
              </h3>

              <div className="relative z-0 w-full group">
                <label className="bg-white relative px-1 top-2 border-1  w-auto text-[16px] text-black font-quasimoda">
                  ¿Cuántos años tienes?
                </label>

                <div className="w-full font-quasimoda">
                  <div className="flex justify-between mt-2 mb-2">
                    <span className="text-gray-600 mx-auto">{edad} años</span>
                  </div>

                  <input
                    type="range"
                    min="18"
                    max="65"
                    value={edad}
                    onChange={(e) => setEdad(Number(e.target.value))}
                    className="w-full accent-primary"
                  />
                </div>
              </div>

              <div className="relative z-0 w-full group">
                <p className="bg-white relative left w-auto text-black font-quasimoda">
                  ¿Cuál es tu género?
                </p>

                <div className="w-full flex flex-col md:flex-row justify-between items-center mt-[10px]">
                  <button
                    onClick={() => setSexo('M')}
                    className={`${
                      sexo === 'M' ? 'bg-primary' : 'bg-white'
                    } text-black font-quasimoda border-1 border-primary rounded-[70px] py-2 px-8`}
                  >
                    Masculino
                  </button>

                  <button
                    onClick={() => setSexo('F')}
                    className={`${
                      sexo === 'F' ? 'bg-primary' : 'bg-white'
                    } text-black font-quasimoda border-1 border-primary rounded-[70px] py-2 px-8`}
                  >
                    Femenino
                  </button>
                </div>
              </div>

              <div className="relative z-0 w-full group">
                <label className="bg-white relative px-1 top-2 left-3 w-auto text-black font-quasimoda">
                  ¿Cuanto ganas al mes (BRUTO)?
                </label>

                <CurrencyInput
                  intlConfig={{ locale: 'es-CL', currency: 'CLP' }}
                  allowDecimals
                  decimalSeparator=","
                  id="input-currency-field"
                  name="input-currency-field-name"
                  prefix="$"
                  value={rentaImponible}
                  onValueChange={handleChangeRentaImponible}
                  step={1}
                  className="focus:border-primary focus:outline-none h-8 text-10  bg-gray-50 border py-55-rem border-1 border-gray-400 text-gray-900 text-sm rounded-lg focus:ring-primary  block w-full p-[25px]"
                />
              </div>

              <div className="relative z-0 w-full group">
                <label className="bg-white relative px-1 top-2 left-3 w-auto text-black font-quasimoda">
                  ¿Cuántos años has cotizado hasta la actualidad?
                </label>
                <div className="w-full font-quasimoda">
                  <div className="flex justify-between mt-2 mb-2">
                    <span className="text-gray-600 mx-auto">{anosCotizados} años</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="65"
                    value={anosCotizados}
                    onChange={(e) => setAnosCotizados(Number(e.target.value))}
                    className="w-full accent-primary"
                  />
                </div>
              </div>

              <div className="relative z-0 w-full group">
                <label className="bg-white relative px-1 top-2 left-3 w-auto text-black font-quasimoda">
                  ¿Cuántos años esperas cotizar desde hoy hasta jubilar?
                </label>
                <div className="w-full font-quasimoda">
                  <div className="flex justify-between mt-2 mb-2">
                    <span className="text-gray-600 mx-auto">{anosRestantes} años</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="65"
                    value={anosRestantes}
                    onChange={(e) => setAnosRestantes(Number(e.target.value))}
                    className="w-full accent-primary"
                  />
                </div>
              </div>
            </div>
            <button
              onClick={resultBtn}
              className="bg-primary rounded-[70px] mt-4 py-2 px-8 md:px-16 mx-auto"
            >
              <p className="text-[16px] text-black font-quasimoda font-bold">🔥 Realiza cálculo</p>
            </button>
          </div>

          {/* configurations */}
          {/* charts */}
          <div className="flex flex-col min-h-full w-full md:w-2/3 items-center mt-[20px]">
            {/* <h3 className="text-xl text-center">Ya estan tus resultados!</h3> */}

            <div className="flex text-[14px] text-third self-end items-center gap-[5px] font-quasimoda ">
              <RiInformation2Line />
              <span className="hover:cursor-pointer" onClick={() => setCalcExplanation(true)}>
                ¿Cómo hicimos el cálculo?
              </span>
            </div>

            <h2 className="font-quasimoda text-4xl">{nombre}, ya están tus resultados!</h2>

            <div className="flex justify-between mt-[10px]">
              <div className="">
                <span className="text-sm text-black font-quasimoda">
                  Si un 3% de cotización extra se destina a tu{' '}
                  <span className="text-primary font-bold">Capitalización Individual</span>,
                  recibirás un beneficio de ${beneficioCI}. En cambio, si destinas el mismo 3% de
                  cotización extra al <span className="text-third font-bold">Seguro Social</span>,
                  recibirás un beneficio de ${beneficioSsp}
                </span>
              </div>
            </div>

            <div ref={barChartRef} className="w-full h-[400px] md:w-[800px] my-[40px] rounded-lg">
              <Bar data={data} options={options} />
            </div>

            <Social bnsp={beneficioSsp} bci={beneficioCI} />
          </div>
        </div>

        {CalcExplanation && <Calculos isOpen={CalcExplanation} onClose={handleExplanation} />}
      </div>
    </>
  );
}
