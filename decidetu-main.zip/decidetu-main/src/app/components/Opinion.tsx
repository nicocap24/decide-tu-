'use client';
import { useState, useRef } from 'react';

//React-icons
import { RiInformation2Line } from 'react-icons/ri';
import { BsEmojiFrown, BsEmojiNeutral, BsEmojiLaughing } from 'react-icons/bs';

//Import modals
import BonoNacer from './_modals/BonoNacer';
import BonoAutPrestamo from './_modals/BonoAutPrestamo';
import BonoLongevidad from './_modals/BonoLongevidad';
import HipotecaInversa from './_modals/HipotecaInversa';
import Consumo from './_modals/Consumo';
type LikeOps = 1 | 2 | 3 | null;
const Opinion = () => {
  const [selectedLike, setSelectedLike] = useState<LikeOps | null>(null);
  const [bonoNacer, setBonoNacer] = useState('No');
  const [autoPrestamo, setAutoPrestamo] = useState('No');
  const [seguroLongevidad, setSeguroLongevidad] = useState('No');
  const [hipotecaInversa, setHipotecaInversa] = useState('No');
  const [cotizacionConsumo, setCotizacionConsumo] = useState('No');
  const [otra, setOtra] = useState('');
  const [formLoading, setFormLoading] = useState(false);
  const msgRef = useRef<HTMLParagraphElement | null>(null);

  //Modal states
  const [bonoNacerModal, setBonoNacerModal] = useState(false);
  const [bonoAutPrestamoModal, setBonoAutPrestamoModal] = useState(false);
  const [bonoLongevidadModal, setBonoLongevidadModal] = useState(false);
  const [hipotecaInversaModal, sethipotecaInversaModal] = useState(false);
  const [consumoModal, setConsumoModal] = useState(false);

  const handleSelect = (id: LikeOps) => {
    setSelectedLike(id);
  };
  const handleBonoNacerModal = () => {
    setBonoNacerModal(false);
  };
  const handleBonoAutPrestamoModal = () => {
    setBonoAutPrestamoModal(false);
  };
  const handleLongevidadModal = () => {
    setBonoLongevidadModal(false);
  };
  const handlehipotecaInversaModal = () => {
    sethipotecaInversaModal(false);
  };
  const handleConsumoModal = () => {
    setConsumoModal(false);
  };

  const handleEnviar = async () => {
    setFormLoading(true);
    // Obtener la fecha y hora actuales en milisegundos desde el epoch
    const now = Date.now();

    // Crear un objeto Date a partir del timestamp actual
    const date = new Date(now);

    // Especificar la región y opciones de formato para Chile
    const options = {
      year: 'numeric' as 'numeric',
      month: '2-digit' as '2-digit',
      day: '2-digit' as '2-digit',
      hour: '2-digit' as '2-digit',
      minute: '2-digit' as '2-digit',
      second: '2-digit' as '2-digit',
      timeZone: 'America/Santiago',
      hour12: false,
    };

    // Crear el formateador de fecha y hora para la región especificada
    const dateTimeFormat = new Intl.DateTimeFormat('es-CL', options);

    // Formatear la fecha
    const formattedDate = dateTimeFormat.format(date);

    let like = '';
    switch (selectedLike) {
      case 1:
        like = 'MALA';
        break;
      case 2:
        like = 'REGULAR';
        break;
      case 3:
        like = 'BUENA';
        break;
    }
    const data = {
      fechaPeticion: formattedDate,
      bonoNacer,
      autoPrestamo,
      seguroLongevidad,
      hipotecaInversa,
      cotizacionConsumo,
      otra,
      impresion: like,
    };
    await fetch('/api/opinion', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
      .then((res) => res)
      .then((r) => {
        if (msgRef.current) msgRef.current.classList.remove('hidden');
      })
      .finally(() => {
        setFormLoading(false);
        setTimeout(() => {
          if (msgRef.current) msgRef.current.classList.add('hidden');
        }, 6000);
      });
  };

  return (
    <div className="w-11/12 relative md:w-[800px] flex flex-col gap-y-3  mt-[40px]">
      <h2 className="text-[30px] text-black font-bold font-quasimoda">
        ¿Qué te pareció esta herramienta?
      </h2>
      <div className="flex items-center justify-center space-x-4">
        <label
          className={`cursor-pointer p-2 ${
            selectedLike === 1 ? 'outline outline-2 outline-blue-500' : ''
          }`}
        >
          <input
            type="radio"
            name="emoji"
            value={1}
            className="hidden"
            onChange={() => handleSelect(1)}
          />
          <div className="text-5xl">
            <BsEmojiFrown size={60} className="text-red-600" />
          </div>
        </label>

        <label
          className={`cursor-pointer p-2 ${
            selectedLike === 2 ? 'outline outline-2 outline-blue-500' : ''
          }`}
        >
          <input
            type="radio"
            name="emoji"
            value={2}
            className="hidden"
            onChange={() => handleSelect(2)}
          />
          <div className="text-5xl">
            <BsEmojiNeutral size={60} className="text-yellow-500" />
          </div>
        </label>

        <label
          className={`cursor-pointer p-2 ${
            selectedLike === 3 ? 'outline outline-2 outline-blue-500' : ''
          }`}
        >
          <input
            type="radio"
            name="emoji"
            value={3}
            className="hidden"
            onChange={() => handleSelect(3)}
          />
          <div className="text-5xl">
            <BsEmojiLaughing size={60} className="text-green-600" />
          </div>
        </label>
      </div>
      <h3 className="text-[30px] text-black font-bold font-quasimoda">
        ¿Qué otras propuestas te gustaría simular?
      </h3>

      <div className="flex justify-between items-center">
        <div className="flex items-center gap-x-1">
          <RiInformation2Line className="mb-1" />
          <span
            onClick={() => setBonoNacerModal(true)}
            className="text-[20px] text-black font-quasimoda hover:cursor-pointer"
          >
            Bono al nacer
          </span>
        </div>

        <label className="relative inline-flex cursor-pointer items-center">
          <input
            type="checkbox"
            className="peer sr-only"
            onChange={(e) => setBonoNacer(e.target.checked ? 'Si' : 'No')}
          />

          <div className="peer h-6 w-11 rounded-full border bg-[#55F5BB] after:absolute after:left-[2px] after:top-0.5 after:h-5 after:w-5 after:rounded-full after:border after:border-gray-300 after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#036d46] peer-checked:after:translate-x-full peer-checked:after:border-white peer-focus:ring-[#036d46]"></div>
        </label>
      </div>

      <div className="flex justify-between items-center">
        <div className="flex items-center gap-x-1">
          <RiInformation2Line className="mb-1" />
          <span
            onClick={() => setBonoAutPrestamoModal(true)}
            className="text-[20px] text-black font-quasimoda hover:cursor-pointer"
          >
            Auto préstamo
          </span>
        </div>

        <label className="relative inline-flex cursor-pointer items-center">
          <input
            type="checkbox"
            className="peer sr-only"
            onChange={(e) => setAutoPrestamo(e.target.checked ? 'Si' : 'No')}
          />
          <label htmlFor="switch" className="hidden"></label>
          <div className="peer h-6 w-11 rounded-full border bg-[#55F5BB] after:absolute after:left-[2px] after:top-0.5 after:h-5 after:w-5 after:rounded-full after:border after:border-gray-300 after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#036d46] peer-checked:after:translate-x-full peer-checked:after:border-white peer-focus:ring-[#036d46]"></div>
        </label>
      </div>

      <div className="flex justify-between items-center">
        <div className="flex items-center gap-x-1">
          <RiInformation2Line className="mb-1" />
          <span
            onClick={() => setBonoLongevidadModal(true)}
            className="text-[20px] text-black font-quasimoda hover:cursor-pointer"
          >
            Seguro de longevidad
          </span>
        </div>

        <label className="relative inline-flex cursor-pointer items-center">
          <input
            type="checkbox"
            className="peer sr-only"
            onChange={(e) => setSeguroLongevidad(e.target.checked ? 'Si' : 'No')}
          />
          <label htmlFor="switch" className="hidden"></label>
          <div className="peer h-6 w-11 rounded-full border bg-[#55F5BB] after:absolute after:left-[2px] after:top-0.5 after:h-5 after:w-5 after:rounded-full after:border after:border-gray-300 after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#036d46] peer-checked:after:translate-x-full peer-checked:after:border-white peer-focus:ring-[#036d46]"></div>
        </label>
      </div>

      <div className="flex justify-between items-center">
        <div className="flex items-center gap-x-1">
          <RiInformation2Line className="mb-1" />
          <span
            onClick={() => sethipotecaInversaModal(true)}
            className="text-[20px] text-black font-quasimoda hover:cursor-pointer"
          >
            Hipoteca inversa
          </span>
        </div>

        <label className="relative inline-flex cursor-pointer items-center hover:cursor-pointer">
          <input
            type="checkbox"
            className="peer sr-only"
            onChange={(e) => setHipotecaInversa(e.target.checked ? 'Si' : 'No')}
          />
          <label htmlFor="switch" className="hidden"></label>
          <div className="peer h-6 w-11 rounded-full border bg-[#55F5BB] after:absolute after:left-[2px] after:top-0.5 after:h-5 after:w-5 after:rounded-full after:border after:border-gray-300 after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#036d46] peer-checked:after:translate-x-full peer-checked:after:border-white peer-focus:ring-[#036d46]"></div>
        </label>
      </div>

      <div className="flex justify-between items-center">
        <div className="flex items-center gap-x-1">
          <RiInformation2Line className="mb-1" />{' '}
          <span
            onClick={() => setConsumoModal(true)}
            className="text-[20px] text-black font-quasimoda hover:cursor-pointer"
          >
            Cotizacion por consumo
          </span>
        </div>

        <label className="relative inline-flex cursor-pointer items-center">
          <input
            type="checkbox"
            className="peer sr-only"
            onChange={(e) => setCotizacionConsumo(e.target.checked ? 'Si' : 'No')}
          />
          <label htmlFor="switch" className="hidden"></label>
          <div className="peer h-6 w-11 rounded-full border bg-[#55F5BB] after:absolute after:left-[2px] after:top-0.5 after:h-5 after:w-5 after:rounded-full after:border after:border-gray-300 after:bg-white after:transition-all after:content-[''] peer-checked:bg-[#036d46] peer-checked:after:translate-x-full peer-checked:after:border-white peer-focus:ring-[#036d46]"></div>
        </label>
      </div>

      <div className="flex gap-x-2">
        <label className="text-[20px] text-black font-quasimoda">Otra</label>
        <input
          type="text"
          onChange={(e) => setOtra(e.target.value)}
          className="h-8 text-10  bg-gray-50 border py-55-rem border-1 border-gray-400 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-2/3 p-2.5"
        />
      </div>

      <button
        onClick={handleEnviar}
        className={`${
          formLoading ? 'bg-[#c1ffe8] cursor-not-allowed' : 'bg-primary'
        } py-2 px-16 rounded-[70px] mt-[20px] max-w-44 mx-auto`}
        disabled={formLoading}
      >
        {formLoading ? (
          <div className="border-[#dffcf1] h-10 w-10 animate-spin rounded-full border-8 border-t-primary" />
        ) : (
          <p className="font-quasimoda text-[20px] font-bold text-black">Enviar</p>
        )}
      </button>
      <p
        ref={msgRef}
        className="hidden bg-[#dffcf1] text-primary text-center font-bold font-quasimoda py-2 "
      >
        Gracias por su opinión
      </p>
      {bonoNacerModal && <BonoNacer isOpen={bonoNacerModal} onClose={handleBonoNacerModal} />}
      {bonoAutPrestamoModal && (
        <BonoAutPrestamo isOpen={bonoAutPrestamoModal} onClose={handleBonoAutPrestamoModal} />
      )}
      {bonoLongevidadModal && (
        <BonoLongevidad isOpen={bonoLongevidadModal} onClose={handleLongevidadModal} />
      )}
      {hipotecaInversaModal && (
        <HipotecaInversa isOpen={hipotecaInversaModal} onClose={handlehipotecaInversaModal} />
      )}
      {consumoModal && <Consumo isOpen={consumoModal} onClose={handleConsumoModal} />}
    </div>
  );
};

export default Opinion;
