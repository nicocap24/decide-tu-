import { IoClose } from 'react-icons/io5';
const stopPropagation = (e: React.MouseEvent) => {
  e.stopPropagation();
};

type ModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

function BonoAutPrestamo({ isOpen, onClose }: ModalProps) {
  return (
    <>
      {isOpen && (
        <div
          onClick={onClose}
          className="absolute max-w-full py-8 flex flex-col items-center  bg-gray-400 bg-opacity-50"
        >
          <div
            className="w-10/12 flex flex-col bg-white p-8 rounded-xl max-h-[90vh] overflow-y-auto"
            onClick={stopPropagation}
          >
            <div className="flex flex-row-reverse pb-2 mb-4  border-b-2 border-gray-300">
              <IoClose className="text-2xl cursor-pointer" onClick={onClose} />
            </div>

            <h3 className="text-center">
              <strong>Bono Auto préstamo</strong>
            </h3>
            <p>
              Con esta propuesta podrías retirar parte de tus ahorros, con un tope (actualmente se
              está planteando 5% de los fondos o $1.000.000) y que este retiro se pagado devuelta
              más intereses.
            </p>

            <button
              onClick={onClose}
              className="bg-[#55F5BB] mt-4 py-2 px-16 rounded-[70px] self-end"
            >
              <p className="text-black">Cerrar</p>
            </button>
          </div>
        </div>
      )}
    </>
  );
}
export default BonoAutPrestamo;
