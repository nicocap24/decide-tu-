import { IoClose } from 'react-icons/io5';
const stopPropagation = (e: React.MouseEvent) => {
  e.stopPropagation();
};

type ModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

function Terms({ isOpen, onClose }: ModalProps) {
  return (
    <>
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed z-[9000] top-0 min-h-screen w-full py-8 flex flex-col items-center justify-center  bg-gray-400 bg-opacity-50 font-quasimoda"
        >
          <div
            className="w-10/12 flex flex-col bg-white p-8 rounded-xl max-h-[80vh] overflow-y-auto"
            onClick={stopPropagation}
          >
            <div className="flex flex-row-reverse pb-2 mb-4  border-b-2 border-gray-300">
              <IoClose className="text-2xl cursor-pointer" onClick={onClose} />
            </div>

            <h3 className="text-center mb-4">
              <strong>Términos y condiciones</strong>
            </h3>
            <p className="text-center mb-3">
              La sociedad PENSION FINANCE SPA (en adelante la “Sociedad”), RUT N°77.205.067-4, con
              domicilio principal en la ciudad de Santiago de Chile, es titular de la página web
              https://www.decidetu.cl/ (en adelante la “Web”). Los presentes términos y condiciones
              (en adelante, los “T&C”) regulan su uso y acceso. Por el solo hecho de hacer uso de la
              Web, se entenderá que el Usuario ha leído, comprende y acepta estos T&C y que es una
              persona con capacidad suficiente para contratar y obligarse conforme a la legislación
              de Chile.
            </p>
            <ol className="list-decimal space-y-2">
              <li>
                <strong>Definiciones</strong>
                <ul className="list-disc pl-5 space-y-2 mt-2 mb-2">
                  <li>
                    <strong>Web: </strong>corresponde a la página web de propiedad de Pension Fi,
                    que, conforme a los presentes T&C, puede ser objeto de Uso por los Usuarios,
                    para realizar simulaciones para comparar las alternativas previsionales que
                    actualmente se discuten. Adicionalmente el Usuario podrá suscribirse para
                    acceder a noticias relacionadas con el avance de las reformas previsionales y
                    demás noticias relacionadas.
                  </li>
                  <li>
                    <strong>Usuarios: </strong>personas naturales que acceden a la Web que, hacen
                    uso del Simulador y/o se suscriben al boletín de noticias de la Web.
                  </li>
                  <li>
                    <strong>Simulador: </strong>es una aplicación web creada por la Sociedad, con el
                    objeto de que los Usuarios puedan completar con datos, pudiendo ser estos
                    completamente hipotéticos o casos imaginarios, a fin de que puedan realizar
                    simulaciones de distintas situaciones que, les permita a los Usuarios comparar
                    los posibles eventos de distribución de cotización adicional y que puedan
                    proponerse como modificación al D.L. N°3.500, de 1980, o cualquier otro evento
                    que pueda configurarse en el futuro y que puedan determinar qué alternativa es
                    más conveniente según qué situación hipotética.
                  </li>
                </ul>
              </li>
              <li>
                <strong>ÁMBITO DE APLICACIÓN</strong>
                <p>
                  Los presentes Términos y Condiciones serán aplicables únicamente a la navegación y
                  acceso a las funciones que ofrece la misma.
                </p>
              </li>
              <li>
                <strong>PLATAFORMA DECIDETÚ</strong>
                <p>
                  La Web faculta a los Usuarios acceder a un simulador que permite simular
                  situaciones hipotéticas basándose en distintos datos para efectos de comparar el
                  beneficio que podrían obtener en distintas situaciones de distribución de la
                  cotización adicional o cualquier otro evento que pueda configurarse en la futura
                  reforma previsional. Los Usuarios podrán hacer cuantas simulaciones deseen, para
                  que puedan comprender de forma estimada qué grupos de personas o con qué
                  condiciones algunos se benefician más de un sistema o de otro.
                </p>
              </li>
              <li>
                <strong>CLÁUSULA GENERAL DE PREVENCIÓN DE ACTIVIDADES ILEGALES</strong>
                <p>
                  Al navegar por la Web, el Usuario acepta y declara que no utilizará la Web para la
                  realización de actividades ilegales o criminales de ningún tipo.
                </p>
              </li>
              <li>
                <strong>SERVICIOS DE LA WEB Y PREVENCIÓN</strong>
                <p>
                  La Web pone a disposición de sus Usuarios un Simulador de efectos estimados de
                  propuestas de reforma previsional. El Simulador permite realizar simulaciones,
                  ingresando ciertos datos necesarios para hacer el cálculo. Los Usuarios pueden
                  hacer cuantas simulaciones deseen, con excepción de simulaciones con el único
                  propósito de generar carga maliciosa en la Web. Los Usuarios en ningún momento se
                  encuentran obligados a proporcionar información propia. De igual forma, el Usuario
                  declara que no espera obtener asesoría de cualquier tipo, puesto que el simulador
                  solo permite visualizar distintos escenarios, pero que en ningún momento se
                  solicita información real o de una entidad suficiente para obtener una simulación
                  personalizada, de modo que el Usuario reconoce que la información que recibe por
                  parte del Simulador, es únicamente de carácter referencial que busca aterrizar en
                  ejemplos concretos las distintas posibilidades de distribución de la cotización
                  adicional. La información presentada por el Simulador , no constituye asesoría
                  previsional ni obligan a los intervinientes a la prestación de un servicio alguno,
                  sino que es únicamente información provista con un fin referencial y con una
                  intención de concientización, mediante la exposición de ejemplos concretos. El
                  Simulador puede ser cargado con información hipotética, no verídica e incluso
                  imposible, por lo que la expectativa de la Sociedad en ningún caso es la de
                  ofrecer un servicio personalizado. Adicionalmente, se realiza la prevención de que
                  la información contenida en la Web es meramente informativa, por lo que la
                  Sociedad no se responsabiliza por lo que pudieren realizar los Usuarios utilizando
                  únicamente la información disponible en la Web y sin haber contrastado con otras
                  fuentes de información.
                </p>
              </li>
              <li>
                <strong>SUSCRIPCIÓN AL BOLETÍN</strong>
                <p>
                  Los Usuarios interesados en mantenerse informados respecto de reformas
                  previsionales o sobre información relevante que pueda modificar lo analizado,
                  relativa al sistema previsional, podrán suscribirse al boletín de noticias que
                  emite la Web. Para suscribirse al boletín, los Usuarios deberán aportar su correo
                  electrónico. La suscripción y, consecuente, entrega del correo electrónico es
                  completamente opcional para el Usuario; esta circunstancia quedará reflejada en el
                  sitio Web para el consentimiento del Usuario. Los Usuarios podrán realizar
                  simulaciones sin necesidad de aportar su correo electrónico. Los datos aportados
                  para la simulación no se vinculan en forma alguna al correo electrónico aportado,
                  así, los datos de la simulación son tratados como datos estadísticos de
                  conformidad con la Política de Privacidad de la Web. La Sociedad reconoce que los
                  datos ingresados en el simulador pueden ser completamente falsos, ficticios,
                  hipotéticos e incluso imposibles, por lo que, no vincula en forma alguna la
                  entrega del correo electrónico opcional para la suscripción al boletín con la
                  información aportada al Simulador. Los Usuarios siempre podrán decidir de
                  suscribirse del boletín mediante el enlace que se encontrará dispuesto en cada
                  comunicación al efecto. El tratamiento del correo electrónico, considerado como
                  dato de carácter personal, se sujetará a la Política de Privacidad del sitio Web.
                </p>
              </li>
              <li>
                <strong>RIESGOS EN LOS SISTEMAS</strong>
                <p>
                  La Web puede verse expuesta a problemas técnicos tales como interrupciones, cortes
                  de energía, fallos de los proveedores, denegación de servicios o cualquier otro
                  evento imputable a fuerza mayor o caso fortuito; por lo que la Sociedad no asegura
                  su disponibilidad en todo momento. De igual forma, tanto por posibles errores
                  temporales en el Simulador, como por cambios en la propuesta de reforma
                  previsional, los cálculos pueden no ser precisos , por tal razón todo cálculo
                  efectuado con el Simulador es solo estimativo y de carácter referencial.
                </p>
              </li>
              <li>
                <strong>MANTENIMIENTO Y ACTUALIZACIÓN DE LA WEB</strong>
                <p>
                  La Sociedad podrá suspender o limitar temporalmente el acceso a la Web, cuando
                  deban efectuarse mantenciones a los sistemas, ocurriese algún caso fortuito o
                  existan circunstancias graves en que el bloqueo o suspensión del servicio se
                  considere necesaria para proteger el interés de los Usuarios. Con o sin motivo de
                  un mantenimiento, la Web podrá ser objeto, en cualquier momento, de actualización,
                  mejoras o modificaciones, lo cual podrá generar cambios en su contenido o en la
                  fórmula de cálculo del Simulador. La Sociedad no garantiza que la Web y/o el
                  Simulador funcione sin errores, ni que su contenido esté libre de virus. La
                  Sociedad no será responsable de ningún daño (incluyendo necesidad de servicio
                  técnico, cambios de equipos y/o pérdida de datos), como resultado del uso de la
                  Web. No obstante, la Sociedad desplegará sus mejores esfuerzos para que estas
                  situaciones no ocurran.
                </p>
              </li>
              <li>
                <strong>PROPIEDAD INTELECTUAL</strong>
                <p>
                  Todo Usuario de la Web, declara conocer que todo el contenido, ya sea gráfico,
                  marca comercial, sus textos, diseños, códigos fuentes, ficheros y compilaciones de
                  datos, que no diga relación con los terceros proveedores, son propiedad exclusiva
                  de sus respectivos dueños, y están protegidos por las leyes de la República de
                  Chile e internacionales sobre propiedad intelectual. A raíz de lo anterior,
                  cualquier Usuario que participe de la Web se abstendrá de su utilización para
                  fines distintos al uso propio de la Web o al uso personal y no comercial en el
                  caso de ficheros descargados. Ninguna imagen, video, ficheros, creación literaria
                  o sonido pueden ser reproducidos, duplicados, copiados, vendidos, revendidos o
                  explotados para ningún fin, en todo o en parte, sin el consentimiento escrito
                  previo de la Sociedad o sus respectivos dueños, ni tampoco atribuirse derechos de
                  propiedad intelectual o industrial sobre aquellos.
                </p>
              </li>
              <li>
                <strong>ATENTADOS Y MALAS PRÁCTICAS</strong>
                <p>
                  El Usuario no deberá atentar contra la Web por medio de ataques de denegación de
                  servicio, saturación de solicitudes, la incorporación de cualquier tipo virus u
                  otro material dañino. Asimismo, el Usuario no debe intentar obtener acceso no
                  autorizado a la Web o parte de ella, al servidor en el que se almacena o cualquier
                  servidor, equipo o base de datos que esté conectado a esta Web. La Sociedad no
                  será responsable de ninguna pérdida o daño causado por un virus que pueda infectar
                  el equipo u ordenador del Usuario o los programas, datos o materiales almacenados
                  en él.
                </p>
              </li>
              <li>
                <strong>MODIFICACIONES DE LOS TÉRMINOS DE USO</strong>
                <p>
                  La Sociedad se reserva el derecho de modificar en cualquier momento estos T&C,
                  dicha modificación puede ser o no producto de una modificación o actualización de
                  la Web.
                </p>
              </li>
              <li>
                <strong>JURISDICCIÓN Y LEY APLICABLE</strong>
                <p>
                  La Web y los servicios entregados por ella están sujetos a estos T&C, así como
                  también se encuentran regidos por la Legislación Chilena y cualquier asunto
                  relacionado con los servicios o productos, deberán ser resueltos bajo esta
                  jurisdicción.
                </p>
              </li>
            </ol>
            <button
              onClick={onClose}
              className="bg-[#55F5BB] mt-4 py-2 px-16 rounded-[70px] self-end"
            >
              <p className="text-black">Cerrar</p>
            </button>
          </div>
        </div>
      )}
    </>
  );
}
export default Terms;
