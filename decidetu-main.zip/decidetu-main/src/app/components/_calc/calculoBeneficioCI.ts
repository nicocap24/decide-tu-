export function calculoBeneficioCI(cnu: number, saldoAcumCI: number) {
  return cnu === 0 ? 0 : Math.round(saldoAcumCI / (cnu * 12));
}
