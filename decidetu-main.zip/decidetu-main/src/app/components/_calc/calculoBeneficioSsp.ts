export function calculoBeneficioSsp(
  cotizacionSSp: number,
  sexo: string,
  tasaCIsobreSueldo: number,
  anosCotizados: number,
  anosRestantes: number,
  valorUF: number,
  saldoAcumRestante: number,
  cnu: number,
  bonoExpectativaVida: number,
  edad: number
) {
  let resultado = 0;
  //console.log('entro a calcular beneficio ssp', edad)
  if (cotizacionSSp > 0 && sexo !== '') {
    let valorInterno = 0;
    if (edad < 50 && anosRestantes === 0) {
      //console.log('devuelve cero')
      return resultado;
    } else {
      if (tasaCIsobreSueldo < 0.06) {
        //console.log('saldo acum restante', saldoAcumRestante)
        let factor = 1;
        if (sexo === 'M') {
          factor = 1.15;
        }
        valorInterno =
          Math.min(30, Number(anosCotizados) + Number(anosRestantes)) * (0.1 * valorUF) -
          saldoAcumRestante / (cnu * 12 * factor);
      }
      resultado += Math.round(Math.max(0, valorInterno));

      if (sexo !== 'M') {
        resultado += bonoExpectativaVida;
      }
    }
  }

  return Math.round(resultado);
}
