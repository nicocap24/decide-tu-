'use client';

import { useState } from 'react';

// components
import Terms from './_modals/Terms';
import Politics from './_modals/Politics';
import Supuestos from './_modals/Supuestos';

export default function NewFooter() {
  //Footer states
  const [terms, setTerms] = useState(false);
  const [politics, setPolitics] = useState(false);
  const [supuestos, setSupuestos] = useState(false);

  const handleTerms = () => {
    setTerms(false);
  };

  const handlePolitics = () => {
    setPolitics(false);
  };

  const handleSupuestos = () => {
    setSupuestos(false);
  };

  return (
    <div className="w-full md:w-[800px] flex flex-col items-center justify-between p-4 bg-white mt-[20px]">
      <p className="text-center text-[#757575] text-[16px] w-full font-quasimoda mb-2">
        <strong>Disclaimer: </strong>Los resultados de este simulador deben considerarse como una
        orientación de carácter informacional y bajo ninguna circunstancia debe considerarse como
        asesoría previsional.
      </p>

      <div className="flex mt-[30px] gap-[20px]">
        <button
          onClick={() => setSupuestos(true)}
          className="text-[#757575] underline hover:text-black"
        >
          Supuestos
        </button>
        <button
          onClick={() => setTerms(true)}
          className="text-[#757575] underline hover:text-black"
        >
          Terminos y condiciones
        </button>
        <button
          onClick={() => setPolitics(true)}
          className="text-[#757575] underline hover:text-black"
        >
          Políticas de privacidad
        </button>
      </div>

      <p className="text-center font-quasimoda mt-[30px]">
        Sitio hecho con ❤️ por{' '}
        <a className="text-cyan-600" href="https://www.pensionfi.com/" target="_blank">
          Pension FI
        </a>
      </p>

      <p className="text-center text-[#757575] text-[13px] w-full font-quasimoda">
        decidetu.cl 2024 © - Todos los derechos reservados
      </p>

      <Terms isOpen={terms} onClose={handleTerms} />
      <Politics isOpen={politics} onClose={handlePolitics} />
      <Supuestos isOpen={supuestos} onClose={handleSupuestos} />
    </div>
  );
}
