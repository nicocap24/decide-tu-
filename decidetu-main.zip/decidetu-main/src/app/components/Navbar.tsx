import { useRouter } from 'next/navigation';
import Image from 'next/image';
export default function Navbar() {
  const router = useRouter();

  return (
    <nav className="flex items-center justify-between p-4 bg-white w-full">
      <button
        onClick={() => {
          router.push('/');
        }}
      >
        <Image src="/assets/landing/logo.png" alt="Logo Decide Tu" width={100} height={100} />
      </button>

      {/* <button className="bg-[#55F5BB] py-2 px-16 rounded-[70px]">
        <p className="text-black">¡Simula y comparte!</p>
      </button> */}
    </nav>
  );
}
