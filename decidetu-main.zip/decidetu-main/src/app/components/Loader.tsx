import React from 'react';

const Loader = () => {
  return (
    <div className="fixed flex flex-col justify-center items-center w-full z-[5000] min-h-screen bg-primary">
      <div className="loader relative inline-block w-12 h-12 border-3 border-solid rounded-full border-t-de3500 border-b-white border-l-transparent border-r-transparent box-border animate-rotate">
        <div className="loader-inner absolute top-0 left-0 border-10 border-transparent border-b-white transform translate-x-[-10px] translate-y-[19px] rotate-[-35deg]"></div>
        <div className="loader-inner-after absolute top-0 left-0 border-10 border-transparent border-t-de3500 transform translate-x-[32px] translate-y-[3px] rotate-[-35deg]"></div>
      </div>
      <p className="mt-2">Estamos calculando...</p>
    </div>
  );
};

export default Loader;
