import type { Metadata } from 'next';

import './globals.css';
import { GoogleAnalytics } from '@next/third-parties/google';
export const metadata: Metadata = {
  icons: {
    icon: '/favicon.png', // /public path
  },
  title: 'decide-tu.cl',
  description: 'Simula tu pensión y comparte con tus amigos',
  openGraph: {
    type: 'website',
    locale: 'es_CL',
    url: 'https://decide-tu.cl',
    title: 'decide-tu.cl',
    description: 'Simula tu pensión y comparte con tus amigos',
    images: [
      {
        url: 'https://decidetu-cl.vercel.app/assets/landing/og-image.png',
        width: 1200,
        height: 630,
        alt: 'decide-tu.cl',
      },
    ],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <>
      <html lang="en">
        <head>
          <script async src="https://www.googletagmanager.com/gtag/js?id=G-Z8Z9E82ESS"></script>
          <script
            dangerouslySetInnerHTML={{
              __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-Z8Z9E82ESS');
          `,
            }}
          ></script>
        </head>
        <body className=" w-full">{children}</body>
      </html>
    </>
  );
}
