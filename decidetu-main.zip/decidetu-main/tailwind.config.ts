import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      borderWidth: {
        '3': '3px',
        '10': '10px',
      },
      borderColor: {
        de3500: 'green',
      },
      animation: {
        rotate: 'rotate 1s linear infinite',
      },
      keyframes: {
        rotate: {
          '100%': { transform: 'rotate(360deg)' },
        },
      },
      fontFamily: {
        quasimoda: ['quasimoda', 'sans-serif'],
      },
      colors: {
        primary: '#55F5BB',
        'primary-with-opacity': '#55F5BB66',
        secondary: '#00072D',
        third: '#FF4A1C',
      },
    },
  },
  plugins: [],
};

export default config;
